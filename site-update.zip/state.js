/* Local demonstration economy. No account, server ledger, or real currency. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SusomoonState = api;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this), function () {
  'use strict';

  var PROFILE_FIELDS = ['name', 'team', 'specialty', 'interests', 'intro'];
  var REWARD_FIELDS = ['team', 'specialty', 'interests', 'intro'];
  var EXPERT_IDS = ['curie', 'einstein', 'feynman', 'hodgkin', 'doudna', 'sharpless', 'jang-yeongsil', 'choe-museon', 'heo-jun', 'hong-daeyong', 'kim-jeongho', 'woo-jangchoon', 'seok-juseon', 'taikyue-ree', 'lee-wonchul', 'rim-hak', 'jo-soontak', 'benjamin-lee', 'dawon-kahng', 'lee-howang', 'hyun-sinkyu', 'heo-moonhoe', 'choi-hyungseop', 'choi-soondal', 'kim-narry', 'june-huh', 'hong-yoonki', 'oh-jinho'];
  var SLOTS = ['finish', 'clothing', 'headwear', 'eyewear', 'earrings', 'necklace', 'badge'];
  var MAX_COMMENTS = 1000;
  var ITEMS = Object.freeze({
    holo: Object.freeze({ id: 'holo', name: '홀로그램', cost: 8, slot: 'finish' }),
    sparkle: Object.freeze({ id: 'sparkle', name: '반짝임', cost: 5, slot: 'finish' }),
    glasses: Object.freeze({ id: 'glasses', name: '안경', cost: 4, slot: 'eyewear' }),
    hat: Object.freeze({ id: 'hat', name: '모자', cost: 6, slot: 'headwear' }),
    atomBadge: Object.freeze({ id: 'atomBadge', name: '원자 배지', cost: 3, slot: 'badge' }),
    mintCoat: Object.freeze({ id: 'mintCoat', name: '민트 연구복', cost: 12, slot: 'clothing' }),
    navyBlazer: Object.freeze({ id: 'navyBlazer', name: '네이비 재킷', cost: 18, slot: 'clothing' }),
    lavenderHoodie: Object.freeze({ id: 'lavenderHoodie', name: '라벤더 후디', cost: 14, slot: 'clothing' }),
    beret: Object.freeze({ id: 'beret', name: '크림 베레모', cost: 8, slot: 'headwear' }),
    cap: Object.freeze({ id: 'cap', name: '연구소 캡', cost: 7, slot: 'headwear' }),
    roundGlasses: Object.freeze({ id: 'roundGlasses', name: '라운드 안경', cost: 6, slot: 'eyewear' }),
    goggles: Object.freeze({ id: 'goggles', name: '투명 고글', cost: 7, slot: 'eyewear' }),
    pearlEarrings: Object.freeze({ id: 'pearlEarrings', name: '진주 귀걸이', cost: 5, slot: 'earrings' }),
    starEarrings: Object.freeze({ id: 'starEarrings', name: '별 귀걸이', cost: 7, slot: 'earrings' }),
    atomNecklace: Object.freeze({ id: 'atomNecklace', name: '원자 목걸이', cost: 8, slot: 'necklace' }),
    pearlNecklace: Object.freeze({ id: 'pearlNecklace', name: '진주 목걸이', cost: 6, slot: 'necklace' }),
    leafBadge: Object.freeze({ id: 'leafBadge', name: '새싹 배지', cost: 4, slot: 'badge' }),
    boltBadge: Object.freeze({ id: 'boltBadge', name: '번개 배지', cost: 5, slot: 'badge' })
  });
  // Prototype price examples only. No real payment can credit this local store.
  var PACKS = Object.freeze({
    starter: Object.freeze({id:'starter', name:'작은 발견', hydrogen:100, price:1000}),
    lab: Object.freeze({id:'lab', name:'나의 연구실', hydrogen:550, price:5000}),
    universe: Object.freeze({id:'universe', name:'지식 유니버스', hydrogen:1200, price:10000})
  });

  function freshState() {
    return {
      version: 2,
      balance: 12,
      profile: { name: '나의 연구자', team: '', specialty: '', interests: '', intro: '' },
      profileRewarded: [],
      comments: [],
      commentRewards: {},
      owned: [],
      equipped: { finish: null, clothing: null, headwear: null, eyewear: null, earrings: null, necklace: null, badge: null },
      demoTopups: []
    };
  }

  function copy(value) { return JSON.parse(JSON.stringify(value)); }
  function isRecord(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }
  function hasItem(id) { return typeof id === 'string' && Object.prototype.hasOwnProperty.call(ITEMS, id); }
  function textValue(value) {
    if (typeof value !== 'string') return null;
    return value.replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  }
  function lengthOf(value) { return Array.from(value).length; }
  function normalizedComment(value) { return value.normalize('NFKC').toLocaleLowerCase('ko-KR').replace(/\s+/g, ' ').trim(); }
  function meaningfulComment(value) { return (value.match(/[\p{L}\p{N}]/gu) || []).length >= 5; }
  function dayInSeoul(date) { return new Date(date.getTime() + 9 * 60 * 60 * 1000).toISOString().slice(0, 10); }
  function rewardKey(expertId, date) { return expertId + '|' + dayInSeoul(date); }
  function validRewardKey(key) {
    if (typeof key !== 'string') return false;
    var parts = key.split('|');
    if (parts.length !== 2 || EXPERT_IDS.indexOf(parts[0]) === -1 || !/^\d{4}-\d{2}-\d{2}$/.test(parts[1])) return false;
    var date = new Date(parts[1] + 'T00:00:00.000Z');
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === parts[1];
  }

  function sanitize(saved) {
    var result = freshState();
    if (!isRecord(saved) || (saved.version !== 1 && saved.version !== 2)) return result;
    if (Number.isSafeInteger(saved.balance) && saved.balance >= 0 && saved.balance <= 1000000) result.balance = saved.balance;

    if (isRecord(saved.profile)) PROFILE_FIELDS.forEach(function (field) {
      var value = textValue(saved.profile[field]);
      if (value !== null && lengthOf(value) <= 200 && (field !== 'name' || value)) result.profile[field] = value;
    });
    if (Array.isArray(saved.profileRewarded)) {
      result.profileRewarded = REWARD_FIELDS.filter(function (field) { return saved.profileRewarded.indexOf(field) !== -1; });
    }

    var seenComments = new Set();
    if (Array.isArray(saved.comments)) saved.comments.slice(0, MAX_COMMENTS).forEach(function (comment, index) {
      if (!isRecord(comment) || EXPERT_IDS.indexOf(comment.expertId) === -1) return;
      var value = textValue(comment.text);
      if (!value || lengthOf(value) > 500 || !meaningfulComment(value)) return;
      var normalized = normalizedComment(value);
      if (seenComments.has(normalized)) return;
      var date = new Date(typeof comment.createdAt === 'string' ? comment.createdAt : NaN);
      if (!Number.isFinite(date.getTime())) return;
      seenComments.add(normalized);
      result.comments.push({
        id: 'c-' + date.getTime().toString(36) + '-' + (index + 1),
        expertId: comment.expertId,
        text: value,
        createdAt: date.toISOString()
      });
    });
    if (isRecord(saved.commentRewards)) Object.keys(saved.commentRewards).slice(0, 6000).forEach(function (key) {
      if (saved.commentRewards[key] === true && validRewardKey(key)) result.commentRewards[key] = true;
    });
    // A persisted comment also proves this scientist's daily reward was used.
    result.comments.forEach(function (comment) {
      result.commentRewards[rewardKey(comment.expertId, new Date(comment.createdAt))] = true;
    });

    if (Array.isArray(saved.owned)) result.owned = Array.from(new Set(saved.owned.filter(hasItem)));
    if (isRecord(saved.equipped)) SLOTS.forEach(function (slot) {
      var id = saved.equipped[slot];
      if (hasItem(id) && ITEMS[id].slot === slot && result.owned.indexOf(id) !== -1) result.equipped[slot] = id;
    });
    // Migrate the old shared accessory slot without resetting the wallet/items.
    if (saved.version === 1 && isRecord(saved.equipped)) {
      var legacy = saved.equipped.accessory;
      if ((legacy === 'hat' || legacy === 'glasses') && result.owned.indexOf(legacy) !== -1) result.equipped[ITEMS[legacy].slot] = legacy;
    }
    var seenTopups = new Set();
    if (Array.isArray(saved.demoTopups)) saved.demoTopups.slice(0,200).forEach(function (entry) {
      if (!isRecord(entry) || entry.kind !== 'demo' || typeof entry.requestId !== 'string' || !Object.prototype.hasOwnProperty.call(PACKS,entry.packId) || !/^[a-zA-Z0-9_-]{16,100}$/.test(entry.requestId) || seenTopups.has(entry.requestId)) return;
      if (typeof entry.createdAt !== 'string' || !Number.isFinite(new Date(entry.createdAt).getTime())) return;
      seenTopups.add(entry.requestId);
      result.demoTopups.push({requestId:entry.requestId,packId:entry.packId,amount:PACKS[entry.packId].hydrogen,kind:'demo',createdAt:entry.createdAt});
    });
    return result;
  }

  /**
   * createStore(storage, key?, {now?}?)
   * storage: localStorage-compatible getItem/setItem; omitted => memory only.
   * now: optional () => Date, timestamp, or ISO string for deterministic demos.
   * Every mutation returns {ok, message, reward?, state}; failures do not mutate.
   * Comment text is plain text: consumers MUST render it with textContent.
   */
  function createStore(storage, key, options) {
    key = typeof key === 'string' && key ? key : 'susomoon-v1';
    options = options || {};
    var now = typeof options.now === 'function' ? options.now : function () { return new Date(); };
    var state = freshState();
    var listeners = new Set();
    var persistenceAvailable = !!(storage && typeof storage.getItem === 'function' && typeof storage.setItem === 'function');
    if (persistenceAvailable) {
      try {
        var raw = storage.getItem(key);
        if (raw !== null) state = sanitize(JSON.parse(raw));
      } catch (_) {
        // A missing, blocked, or corrupt read must not crash the prototype.
        state = freshState();
      }
    }

    function getState() { return copy(state); }
    function failure(message) { return { ok: false, message: message, state: getState() }; }
    function commit(next, message, reward) {
      if (persistenceAvailable) {
        try { storage.setItem(key, JSON.stringify(next)); }
        catch (_) { return failure('브라우저 저장 공간에 기록하지 못했습니다. 설정을 확인한 뒤 다시 시도해 주세요.'); }
      }
      state = next;
      listeners.forEach(function (listener) {
        try { listener(getState()); } catch (_) { /* A view error must not reverse a saved transaction. */ }
      });
      var response = { ok: true, message: message, state: getState() };
      if (typeof reward === 'number') response.reward = reward;
      return response;
    }

    function addProfile(field, value) {
      if (PROFILE_FIELDS.indexOf(field) === -1) return failure('지원하지 않는 프로필 항목입니다.');
      value = textValue(value);
      if (!value) return failure('내용을 입력해 주세요.');
      if (lengthOf(value) > 200) return failure('프로필 항목은 200자 이내로 입력해 주세요.');
      var next = getState();
      var reward = 0;
      next.profile[field] = value;
      if (REWARD_FIELDS.indexOf(field) !== -1 && next.profileRewarded.indexOf(field) === -1) {
        next.profileRewarded.push(field);
        next.balance += 3;
        reward = 3;
      }
      return commit(next, reward ? '프로필을 완성했어요. 수소 +3 H₂' : '프로필을 업데이트했어요. 이 항목의 보상은 한 번만 지급됩니다.', reward);
    }

    function addComment(expertId, text) {
      if (EXPERT_IDS.indexOf(expertId) === -1) return failure('전문가 카드를 확인해 주세요.');
      text = textValue(text);
      if (!text || !meaningfulComment(text)) return failure('의미 있는 글자 5자 이상으로 연구 의견을 남겨 주세요.');
      if (lengthOf(text) > 500) return failure('의견은 500자 이내로 입력해 주세요.');
      var normalized = normalizedComment(text);
      if (state.comments.some(function (comment) { return normalizedComment(comment.text) === normalized; })) return failure('같은 의견은 중복으로 등록할 수 없어요.');
      if (state.comments.length >= MAX_COMMENTS) return failure('이 데모에서 저장할 수 있는 의견 수에 도달했어요.');
      var date;
      try { date = new Date(now()); } catch (_) { return failure('현재 날짜를 확인하지 못했습니다.'); }
      if (!Number.isFinite(date.getTime())) return failure('현재 날짜를 확인하지 못했습니다.');
      var next = getState();
      var dailyKey = rewardKey(expertId, date);
      var reward = next.commentRewards[dailyKey] ? 0 : 1;
      next.comments.push({ id: 'c-' + date.getTime().toString(36) + '-' + (next.comments.length + 1), expertId: expertId, text: text, createdAt: date.toISOString() });
      next.commentRewards[dailyKey] = true;
      next.balance += reward;
      return commit(next, reward ? '의견을 남겼어요. 수소 +1 H₂' : '의견을 남겼어요. 같은 카드의 보상은 하루 한 번입니다.', reward);
    }

    function purchase(itemId) {
      if (!hasItem(itemId)) return failure('존재하지 않는 아이템입니다.');
      var item = ITEMS[itemId];
      if (state.owned.indexOf(itemId) !== -1) return equip(item.slot, itemId);
      if (state.balance < item.cost) return failure('수소가 부족해요. 수소를 모으거나 충전소를 이용해 주세요.');
      var next = getState();
      next.balance -= item.cost;
      next.owned.push(itemId);
      next.equipped[item.slot] = itemId;
      return commit(next, item.name + '을(를) 구매하고 카드에 적용했어요. −' + item.cost + ' H₂', 0);
    }

    function equip(slot, itemId) {
      if (SLOTS.indexOf(slot) === -1) return failure('지원하지 않는 꾸미기 위치입니다.');
      if (itemId !== null && (!hasItem(itemId) || ITEMS[itemId].slot !== slot)) return failure('이 위치에 적용할 수 없는 아이템입니다.');
      if (itemId !== null && state.owned.indexOf(itemId) === -1) return failure('먼저 아이템을 구매해 주세요.');
      var next = getState();
      next.equipped[slot] = itemId;
      return commit(next, itemId === null ? '장식을 해제했어요.' : ITEMS[itemId].name + '을(를) 적용했어요. 추가 수소는 사용하지 않습니다.', 0);
    }

    function demoTopup(packId, requestId) {
      if (typeof packId !== 'string' || !Object.prototype.hasOwnProperty.call(PACKS,packId) || typeof requestId !== 'string' || !/^[a-zA-Z0-9_-]{16,100}$/.test(requestId)) return failure('충전 상품을 확인해 주세요.');
      var previous=state.demoTopups.find(function(entry){return entry.requestId===requestId;});
      if(previous) return previous.packId===packId ? {ok:true,message:'이미 반영된 체험 충전입니다.',reward:0,state:getState()} : failure('이미 사용한 충전 요청입니다.');
      var pack=PACKS[packId];
      if(state.demoTopups.length>=200 || state.balance+pack.hydrogen>1000000) return failure('이 브라우저의 체험 충전 한도에 도달했습니다.');
      var date;try{date=new Date(now());}catch(_){return failure('현재 날짜를 확인하지 못했습니다.');}
      if(!Number.isFinite(date.getTime()))return failure('현재 날짜를 확인하지 못했습니다.');
      var next=getState();next.balance+=pack.hydrogen;
      next.demoTopups.push({requestId:requestId,packId:packId,amount:pack.hydrogen,kind:'demo',createdAt:date.toISOString()});
      return commit(next,'체험용 수소 +'+pack.hydrogen+' H₂ · 실제 결제 0원',pack.hydrogen);
    }

    return Object.freeze({
      getState: getState,
      addProfile: addProfile,
      addComment: addComment,
      purchase: purchase,
      equip: equip,
      demoTopup: demoTopup,
      clearEquipment: function () {
        var next=getState();SLOTS.forEach(function(slot){next.equipped[slot]=null;});
        return commit(next,'기본 스타일로 돌아왔어요. 구매한 아이템은 옷장에 보관됩니다.',0);
      },
      resetDemo: function () { return commit(freshState(), '로컬 데모를 처음 상태로 초기화했어요.', 0); },
      subscribe: function (listener) {
        if (typeof listener !== 'function') throw new TypeError('subscribe expects a function');
        listeners.add(listener);
        return function () { listeners.delete(listener); };
      }
    });
  }

  return Object.freeze({
    createStore: createStore,
    ITEMS: ITEMS,
    PACKS: PACKS,
    SLOTS: Object.freeze(SLOTS.slice()),
    EXPERT_IDS: Object.freeze(EXPERT_IDS.slice()),
    REWARD_FIELDS: Object.freeze(REWARD_FIELDS.slice()),
    DEMO_NOTE: '수소는 이 브라우저에만 저장되는 데모 크레딧입니다. 실제 결제·계정 동기화·위변조 방지 기능은 없습니다.'
  });
});
