/* Pure animated sphere projection; DOM cards and links share positions[id]. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SusomoonOrbit = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';

  const TAU = Math.PI * 2;
  const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const finite = value => typeof value === 'number' && Number.isFinite(value) ? value : 0;
  const phase = value => value % TAU;
  const identity = [0, 0, 0, 1];
  // The fixed H2 origin occupies z=0. Keep even tiny positive/negative depths
  // on the correct side of its layer instead of rounding them onto the center.
  function layerForDepth(z) {
    const depth=clamp(finite(z),-1,1);
    return 1000+Math.sign(depth)*Math.max(1,Math.round(Math.abs(depth)*500));
  }
  function normalizeRotation(value) {
    if (!Array.isArray(value) || value.length !== 4 || !value.every(Number.isFinite)) return identity.slice();
    const max = Math.max(...value.map(Math.abs));
    if (!max) return identity.slice();
    const scaled = value.map(x => x / max), length = Math.hypot(...scaled);
    return scaled.map(x => x / length);
  }
  function compose(a, b) {
    const [x,y,z,w]=a,[X,Y,Z,W]=b;
    return normalizeRotation([w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z]);
  }
  function rotateVector(v, q) {
    const [x,y,z,w]=q,[X,Y,Z]=v;
    const tx=2*(y*Z-z*Y),ty=2*(z*X-x*Z),tz=2*(x*Y-y*X);
    return [X+w*tx+y*tz-z*ty,Y+w*ty+z*tx-x*tz,Z+w*tz+x*ty-y*tx];
  }
  // Camera-space arcball: the screen center remains the pivot, including when zoomed.
  // The smooth hyperbolic rim keeps drags outside the visible ball responsive.
  function ballPoint(point, bounds) {
    const x=(point.x-bounds.centerX)/bounds.radiusX,y=(bounds.centerY-point.y)/bounds.radiusY;
    const radius=Math.hypot(x,y),z=radius<Math.SQRT1_2?Math.sqrt(1-radius*radius):0.5/radius;
    const length=Math.hypot(x,y,z);
    return [x/length,y/length,z/length];
  }
  function drag(rotation, from, to, bounds) {
    const current=normalizeRotation(rotation);
    if(!from||!to||!bounds||![from.x,from.y,to.x,to.y,bounds.centerX,bounds.centerY,bounds.radiusX,bounds.radiusY].every(Number.isFinite)||bounds.radiusX<=0||bounds.radiusY<=0)return current;
    const a=ballPoint(from,bounds),b=ballPoint(to,bounds);
    const cross=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
    return compose(normalizeRotation([...cross,1+a[0]*b[0]+a[1]*b[1]+a[2]*b[2]]),current);
  }
  function turn(rotation, dx, dy, radiansPerPixel) {
    const current=normalizeRotation(rotation);
    if(![dx,dy,radiansPerPixel].every(Number.isFinite))return current;
    const length=Math.hypot(dx,dy);if(!length)return current;
    const half=phase(length*radiansPerPixel)/2,s=Math.sin(half);
    return compose([dy/length*s,dx/length*s,0,Math.cos(half)],current);
  }
  function put(map, id, value) {
    // An ID is a map key, including names that overlap Object.prototype.
    Object.defineProperty(map, id, { value, enumerable: true, configurable: true, writable: true });
  }

  /**
   * sample(experts, timeSeconds, { yaw = 0, rotation = [0,0,0,1] } = {})
   * The camera and center stay fixed. rotation is an arcball quaternion,
   * allowing the whole rigid sphere to turn freely without Euler-angle poles.
   * yaw/time provide the slow automatic orbit; card face angles are DEGREES.
   * Positive z is nearer the viewer. Time is elapsed animation time,
   * never read from the clock. Keep time fixed to pause/reduce motion.
   * Input order determines the Fibonacci slots. Invalid/duplicate IDs are
   * ignored; inputs are not modified. Each call returns fresh maps and values.
   */
  function sample(experts, timeSeconds, options) {
    const positions = {}, depths = {};
    const result = { width: 1000, height: 760, overview: false, positions, depths };
    const seen = new Set();
    const people = (Array.isArray(experts) ? experts : []).filter(person => {
      if (!person || typeof person.id !== 'string' || !person.id || seen.has(person.id)) return false;
      seen.add(person.id);
      return true;
    });
    const count = people.length;
    if (!count) return result;
    if (count === 1) {
      put(positions, people[0].id, [500, 380, 0]);
      put(depths, people[0].id, { z: 1, scale: 1.15, opacity: 1, rotateY: 0 });
      return result;
    }

    options = options && typeof options === 'object' ? options : {};
    const time = finite(timeSeconds);
    // Reduce each finite angle before adding, avoiding overflow at large input.
    const yaw = phase(finite(options.yaw)) + phase(time * 0.11);
    const rotation = normalizeRotation(options.rotation);
    // The camera does not move; manual rotation acts on the sphere in view space.
    const pitch = 0.12;
    const cosYaw = Math.cos(yaw), sinYaw = Math.sin(yaw);
    const cosPitch = Math.cos(pitch), sinPitch = Math.sin(pitch);

    people.forEach((person, index) => {
      // Half-step latitude avoids poles and distributes even small sets evenly.
      const latitude = 1 - 2 * (index + 0.5) / count;
      const ringRadius = Math.sqrt(Math.max(0, 1 - latitude * latitude));
      const azimuth = index * GOLDEN_ANGLE + Math.PI / 4;
      const x = Math.cos(azimuth) * ringRadius;
      const z = Math.sin(azimuth) * ringRadius;

      const yawX = x * cosYaw + z * sinYaw;
      const yawZ = z * cosYaw - x * sinYaw;
      const viewY = latitude * cosPitch - yawZ * sinPitch;
      const viewZ = latitude * sinPitch + yawZ * cosPitch;
      const [rotatedX,rotatedY,rawZ] = rotateVector([yawX,viewY,viewZ],rotation);
      const rotatedZ = clamp(rawZ,-1,1);
      const perspective = 3.6 / (3.6 - rotatedZ);
      // Continuous floating-point coordinates prevent stepped RAF animation.
      const screenX = clamp(500 + rotatedX * 355 * perspective, 110, 890);
      const screenY = clamp(380 - rotatedY * 248 * perspective, 100, 660);
      const near = (rotatedZ + 1) / 2;
      const angle = rotatedX * 3;

      put(positions, person.id, [screenX, screenY, angle]);
      put(depths, person.id, {
        z: rotatedZ,
        scale: 0.62 + near * 0.53,
        opacity: 0.45 + near * 0.55,
        // Billboard-like card faces remain readable rather than turning away.
        rotateY: clamp(-rotatedX * 13.5, -15, 15)
      });
    });
    return result;
  }

  return Object.freeze({ sample, drag, turn, layerForDepth });
});
