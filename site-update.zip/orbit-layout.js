/* Pure animated sphere projection; DOM cards and links share positions[id]. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SusomoonOrbit = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';

  const TAU = Math.PI * 2;
  const GOLDEN_ANGLE = Math.PI * (3 - Math.sqrt(5));
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const finite = value => typeof value === 'number' && Number.isFinite(value) ? value : 0;
  const phase = value => value % TAU;
  function put(map, id, value) {
    // An ID is a map key, including names that overlap Object.prototype.
    Object.defineProperty(map, id, { value, enumerable: true, configurable: true, writable: true });
  }

  /**
   * sample(experts, timeSeconds, { yaw = 0, pitch = 0 } = {})
   * yaw/pitch are additive camera angles in RADIANS; returned card angles are
   * DEGREES. Positive z is nearer the viewer. Time is elapsed animation time,
   * never read from the clock. Keep time fixed to pause/reduce motion.
   * Input order determines the Fibonacci slots. Invalid/duplicate IDs are
   * ignored; inputs are not modified. Each call returns fresh maps and values.
   */
  function sample(experts, timeSeconds, options) {
    const positions = {}, depths = {};
    const result = { width: 1000, height: 760, overview: false, positions, depths };
    const seen = new Set();
    const people = (Array.isArray(experts) ? experts : []).filter(person => {
      if (!person || typeof person.id !== 'string' || !person.id || seen.has(person.id)) return false;
      seen.add(person.id);
      return true;
    });
    const count = people.length;
    if (!count) return result;
    if (count === 1) {
      put(positions, people[0].id, [500, 380, 0]);
      put(depths, people[0].id, { z: 1, scale: 1.15, opacity: 1, rotateY: 0 });
      return result;
    }

    options = options && typeof options === 'object' ? options : {};
    const time = finite(timeSeconds);
    // Reduce each finite angle before adding, avoiding overflow at large input.
    const yaw = phase(finite(options.yaw)) + phase(time * 0.11);
    const pitch = phase(finite(options.pitch)) + 0.12 + Math.sin(phase(time * 0.18)) * 0.06;
    const cosYaw = Math.cos(yaw), sinYaw = Math.sin(yaw);
    const cosPitch = Math.cos(pitch), sinPitch = Math.sin(pitch);

    people.forEach((person, index) => {
      // Half-step latitude avoids poles and distributes even small sets evenly.
      const latitude = 1 - 2 * (index + 0.5) / count;
      const ringRadius = Math.sqrt(Math.max(0, 1 - latitude * latitude));
      const azimuth = index * GOLDEN_ANGLE + Math.PI / 4;
      const x = Math.cos(azimuth) * ringRadius;
      const z = Math.sin(azimuth) * ringRadius;

      const rotatedX = x * cosYaw + z * sinYaw;
      const yawZ = z * cosYaw - x * sinYaw;
      const rotatedY = latitude * cosPitch - yawZ * sinPitch;
      const rotatedZ = clamp(latitude * sinPitch + yawZ * cosPitch, -1, 1);
      const perspective = 3.6 / (3.6 - rotatedZ);
      const floatingX = Math.sin(phase(time * 0.43) + azimuth) * 4;
      const floatingY = Math.cos(phase(time * 0.57) + azimuth) * 6;
      // Continuous floating-point coordinates prevent stepped RAF animation.
      const screenX = clamp(500 + rotatedX * 355 * perspective + floatingX, 110, 890);
      const screenY = clamp(380 - rotatedY * 248 * perspective + floatingY, 100, 660);
      const near = (rotatedZ + 1) / 2;
      const angle = clamp(rotatedX * 3 + Math.sin(phase(time * 0.45) + azimuth) * 2.4, -8, 8);

      put(positions, person.id, [screenX, screenY, angle]);
      put(depths, person.id, {
        z: rotatedZ,
        scale: 0.62 + near * 0.53,
        opacity: 0.45 + near * 0.55,
        // Billboard-like card faces remain readable rather than turning away.
        rotateY: clamp(-rotatedX * 13.5, -15, 15)
      });
    });
    return result;
  }

  return Object.freeze({ sample });
});
