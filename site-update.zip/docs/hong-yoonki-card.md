# 홍윤기 연구자 카드 · 2026-09-21

현재 카드는 윤곽선과 형태를 단순화한 캐릭터 버전입니다. 최신 이미지 파일은 assets/hong-yoonki-character-v2.png, assets/cards/hong-yoonki-character-v2.webp, assets/thumbs/hong-yoonki-character-v2.webp입니다. 이전 이미지는 로컬에 보관했습니다. 최신 제작 프롬프트는 hong-yoonki-character-v2.md를 참고하세요. 아래 이미지 제작 항목은 최초 버전의 기록입니다.

사용자가 제공한 연구 이력서와 사진으로 공개 프로필을 추가했습니다. 노벨 수상자 6명, 한국 과학자 20명은 그대로 두고 별도의 연구자 1명을 더해 총 27명입니다. 가상 직원 데이터는 포함하지 않습니다.

## 카드 내용과 출처

- 촉매공학, 바이오매스 전환, 올레핀·고분자 및 윤활기유를 전문 분야로 정리했습니다.
- 논문 9편: 제1저자 3편과 공동저자 6편. 모든 항목에 DOI, 저자, 학술지, 요약이 있습니다.
- 특허 대표 문헌 19개 항목: 고려대학교 산학협력단 3개, LG화학 15개, GS칼텍스 1개. 공동발명자·공보 번호·발행일·공보 링크를 연결했습니다. 출원인 이름을 현재 소속으로 사용하지 않습니다.
- 19개는 이력서에 수록된 대표 공보 항목 수이며 전체 특허 수·독립 발명 수·현재 유효한 권리 수가 아닙니다. 해외 대응 공보를 별도로 합산하지 않습니다.
- 논문·특허 목록과 요약의 기본 출처는 제공 이력서입니다. 대표 연구와 일부 특허는 아래 공개 자료로 대조했습니다. 모든 논문의 전문을 검토하거나 모든 특허의 법적 상태를 확인한 것은 아닙니다.
- 이력서 원본, 제공 사진 원본, 연락처, 재직 정보는 공개 배포에 포함하지 않습니다.

공개 대조 자료:

- [고려대학교 연구정보: 황화 Ni/W/TiO₂ 촉매 논문](https://pure.korea.ac.kr/en/publications/the-catalytic-activity-of-sulfided-niwtiosub2sub-anatase-for-the-/)
- [대표 Pd/WOx/γ-Al₂O₃ 논문 DOI](https://doi.org/10.1016/j.apcatb.2013.12.045)
- [올레핀 올리고머화 공동발명 US10688482B2](https://patents.google.com/patent/US10688482B2/en)
- [고분자 물성 예측 공동발명 KR102068795B1](https://patents.google.com/patent/KR102068795B1/ko)
- [올레핀 중합체 EP3476870A1 및 대응 등록공보 이력](https://patents.google.com/patent/EP3476870A1/en)
- [냉동기유 베이스 오일 공동발명 KR102958116B1](https://patents.google.com/patent/KR102958116B1/en)

전체 문헌 링크는 researcher-data.js와 카드의 업적 탭에 있습니다. 샤플리스(촉매·반응 설계), 이태규(물성과 분자 특성), 아인슈타인(냉동 기술)과의 선은 서비스가 제안한 개념적 연관입니다. 실제 공동연구, 기술 계승 또는 동일 반응계라고 주장하지 않습니다.

## 뒷면 · 3문장 / 8키워드

바이오매스 유래 물질을 전환하는 촉매와 배기가스 저감 촉매를 공동 연구했습니다.
올레핀 공정·고분자 물성 예측·블록 공중합체의 공동발명에 참여했습니다.
냉동기유용 폴리올에스테르 베이스 오일도 공동발명했습니다.

촉매 · 바이오매스 · 수첨탈산소 · NOx 저감 · 올레핀 · 고분자 · 윤활기유 · 폴리올에스테르

## 이미지 제작

모드: Codex 내장 imagegen, 제공 사진을 참조한 캐리커처 생성. 얼굴 참조 1장과 기존 샤플리스 카드의 화풍 참조 1장을 분리해서 사용했습니다. 사진의 얼굴·피부색·머리·둥근 안경을 유지하고 실험복·고글·촉매/바이오매스/고분자 연구 배경을 창작했습니다.

저장 파일:

- assets/hong-yoonki.png: 생성 원본 1024×1536
- assets/cards/hong-yoonki.webp: 상세 카드 640×960
- assets/thumbs/hong-yoonki.webp: 회전 지도·목록 240×360

제작 프롬프트 요약 (영문):

> Create a polished vertical 2:3 warm 3D caricature for a scientist trading card. Use the first reference only for the identity of Hong Yoon-Ki and the second reference only for the established card illustration style. Preserve his recognizable facial proportions, skin tone, short side-parted dark hair, round thin gold glasses and gentle closed-mouth expression. Dress him in a white lab coat over a blue shirt and navy tie; clear safety goggles may rest on his forehead. Center the face in the upper half. Use a teal, green and amber laboratory background suggesting catalysis, biomass conversion, polymers and lubricant base oils: a reactor, leaves, catalyst granules, molecular chains and a closed amber vial. Make it welcoming and richly detailed. No lettering, logos, Nobel symbols, other people or claims of an award.

WebP 변환은 크기 조절·압축만 수행했습니다. 이번 카드 제작에 내장 이미지 생성을 사용한 것이며, 공개 앱의 사진 업로드 AI 서버 연결 상태를 변경하지 않았습니다.

## 구현과 검증

researcher-data.js를 분리해 카탈로그·지도·컬렉션·검색·방명록에 연결했습니다. 논문 목록과 특허 기관별 목록을 펼쳐 볼 수 있도록 구성했습니다. 기존 브라우저의 수소와 옷장 저장 키는 유지합니다.

문헌이 많은 프로필이 단순 문헌 개수만으로 검색을 독점하지 않도록 일치 주제 수를 우선하고 문헌 개수의 점수 기여를 제한했습니다. ‘클릭 화학 촉매’에서는 샤플리스가 먼저 나오며, 홍윤기는 촉매 관련 부분 일치로 함께 표시됩니다. ‘바이오매스 수첨탈산소’, ‘윤활기유’, ‘polyol ester’에서는 홍윤기가 검색됩니다.

자동 검사: 기존 88개와 신규 연구자·검색·저장·분류·출처 검사 5개. 화면 확인 결과는 배포 후 로컬 전달 기록에 추가합니다.
