# 홍윤기 캐릭터 스타일 수정 · 2026-09-21

요청: 기존 이미지의 실사 느낌을 줄이고 더 캐릭터화.

모드: Codex 내장 imagegen / style-transfer. 이전 생성 이미지가 편집 대상이며, 사용자가 제공한 사진을 얼굴 특징의 보조 참조로 사용했습니다.

선명한 윤곽선, 단순한 명암과 형태를 사용하는 캐릭터 일러스트로 수정했습니다. 둥근 안경·얼굴형·짧은 옆가르마와 표정, 실험복·고글·실험실 배경을 유지했습니다.

저장 경로(프로젝트 기준):

- assets/hong-yoonki-character-v2.png
- assets/cards/hong-yoonki-character-v2.webp
- assets/thumbs/hong-yoonki-character-v2.webp

기존 PNG는 로컬 프로젝트에 보관하고 화면은 새 파일명을 사용합니다. 원본 사진과 이력서, 논문·특허·크레딧 데이터는 수정하지 않았습니다. WebP는 크기 조절·압축만 수행했습니다.

## 사용한 최종 프롬프트

```text
Use case: style-transfer.
Asset type: finished vertical 2:3 scientist character illustration for the Susomoon trading card, no card frame or lettering.
Input image 1 is the edit target: the previous portrait of Hong Yoon-Ki in his science laboratory. Input image 2 is an identity reference only, his original supplied photograph.
Primary request: redraw the entire first image as a clearly illustrated, appealing game character, much more cartoon-like and MUCH less realistic. The face must be drawn in the same cartoon style as the body and background; do not retain photographic skin or paste a photo face onto a cartoon.
Style/medium: polished hand-drawn 2D character art with confident clean dark-teal outlines, simplified bold shapes, smooth flat colors and two or three cel-shaded tones per shape. A charming collectible-card illustration with a gently oversized head, compact upper body and lively but restrained friendly expression. Hair should be a handful of readable graphic locks, skin should have no pores, cloth should be simplified shaded planes, and the lab should look painted rather than photographed. This is a recognizable adult researcher character, not an infant or a generic anime hero.
Identity invariants: preserve the person's recognizable broad rounded face, short dark side-parted haircut and side sweep, thin round gold-rimmed glasses, eyebrow shape, characteristic eye spacing, nose and gentle closed-mouth smile, ears and natural skin tone. Simplify these distinctive features into cartoon shapes without replacing them. Make the eyes only moderately larger.
Composition invariants: keep the vertical upper-body portrait and face clearly visible in the upper half, white lab coat, blue shirt, dark navy tie, clear safety goggles resting above the forehead, one hand holding a small CLOSED amber sample vial. Preserve the teal, green and amber laboratory theme with simplified catalyst jars, plant/biomass details, reactor glassware and a polymer molecular model. Reduce fine background detail so the character reads at a small card size. No new props or characters.
Lighting: graphic soft highlights and cel-shaded shadows, cheerful professional character-design mood.
Avoid: photorealism, 3D skin rendering, lifelike skin texture, individual hair strands, lens blur, photographic lighting, photomontage, large anime eyes, logos, text, watermark, Nobel/award emblems, extra fingers.
Deliver one finished 1024x1536 illustration.
```
