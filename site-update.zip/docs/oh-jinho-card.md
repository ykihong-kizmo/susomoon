# 오진호 연구자 카드 · 2026-09-21

사용자가 제공한 연구이력서와 사진을 바탕으로 수소문에 추가했습니다. 논문 제목·저자·DOI·서지 정보와 대표 특허 공보 번호는 제공 이력서 기준입니다. 원본 이력서와 사진은 공개 빌드에 포함하지 않습니다.

## 공개 카드

- 연구자 컬렉션: 홍윤기·오진호 2명. 전체 공개 인물 28명(노벨 수상자6명, 한국 과학자20명 포함).
- 논문15편: 연구논문13편·리뷰2편. 제1저자 또는 공동 제1저자7편.
- 대표 특허 공보12건: 한국 등록공보9건, 한국/국제 공개공보3건. 독립 발명 수·특허군 수 또는 현재 유효한 권리 수와 구분합니다.
- 현재 소속·직급을 추정하지 않습니다. 특허의 출원인은 해당 문헌의 기관 정보입니다.
- 카드 뒷면: 대표 업적3문장, 키워드8개. LOHC·수소 저장·탈수소화·CO₂ 전환을 한국어와 영어로 검색할 수 있습니다.
- 홍윤기·샤플리스·이태규와 연구 주제를 잇는 연결선은 개념 연결이며 실제 협업을 나타내지 않습니다.

## 대표 공개 출처 대조

전체 목록은 제공 이력서를 기준으로 옮겼으며 모든 논문 전문이나 현재 특허 권리 상태를 검증했다는 뜻은 아닙니다. 아래 대표 출처에서 논문 서지·저자 또는 공보를 대조했습니다.

- [2019년 Pd–Al₂O₃ LOHC 논문](https://www.nature.com/articles/s42004-019-0167-7): 오진호·H. B. Bathula 공동 제1저자 표기 확인.
- [2022년 Pt 촉매의 가역 수소 저장·방출 논문](https://www.sciencedirect.com/science/article/pii/S0926337322000017).
- [2026년 CO₂ 수소화 메커니즘 논문](https://www.sciencedirect.com/science/article/pii/S2666523926000358).
- [KR102954789B1: CO₂ 전환 촉매](https://patents.google.com/patent/KR102954789B1/en).
- [KR102714383B1: 가역 수소화·탈수소화 촉매](https://patents.google.com/patent/KR102714383B1/en).
- [KR101344708B1: 생분해성 에스테르 윤활기유](https://patents.google.com/patent/KR101344708B1/ko).

## 이미지 제작

모드: Codex 내장 imagegen / 제공 사진 기반 캐릭터 변환. 제공 사진만 인물 특징의 참조로, 승인된 홍윤기 그림은 스타일 참조로 사용했습니다. 얼굴형·미소·앞머리·묶은 머리·줄무늬 셔츠를 살리고 실험복과 고글, 수소·CO₂ 전환 연구실 배경을 더했습니다. 배경과 실험 소품은 분야를 나타내는 창작 표현입니다.

- 원본 생성물: assets/oh-jinho-character.png (1024×1536)
- 상세 카드: assets/cards/oh-jinho-character.webp (640×960)
- 지도·목록: assets/thumbs/oh-jinho-character.webp (240×360)

WebP는 생성물의 크기 조절·압축만 수행했습니다. 앱의 사진 업로드 AI 서버 연결 상태는 이번 작업으로 바뀌지 않습니다.

### 최종 생성 프롬프트

```text
Use case: stylized-concept / identity-preserving character portrait.
Asset type: finished vertical 2:3 scientist illustration for the Susomoon researcher card, 1024x1536, without text or card frame.
Input image 1: the user's supplied photograph of Jinho Oh. Use this as the ONLY identity reference. Preserve this person's appearance regardless of assumptions about the name.
Input image 2: the approved Hong Yoon-Ki character card. Use this ONLY for the illustrated style, composition quality and color harmony. Do NOT transfer that person's face, hairstyle, glasses or clothing details to Jinho.
Primary request: create a recognizable, friendly ADULT cartoon scientist character from image 1, matching the illustrated collectible-card look of image 2. Clean confident outlines, simplified graphic shapes, two-to-three-tone cel shading, gently oversized head and compact torso. The entire face, body and laboratory must be illustrated; avoid photorealistic skin or a photograph pasted into a cartoon.
Identity: preserve the oval face, softly shaped eyes and their spacing, small nose, smiling lips with a little upper teeth visible, natural skin tone, dark brown tied-back hair with straight light bangs and longer side strands. No eyeglasses. Keep the familiar smile and facial proportions while simplifying details, and do not substitute a generic anime face.
Wardrobe: a white lab coat over the recognizable white shirt with narrow dark vertical stripes from the source photo. Clear laboratory safety goggles resting on top of the head so the face remains fully visible. Professional, unsexualized, warm and approachable.
Research backdrop: a tidy teal and emerald catalysis lab representing liquid organic hydrogen carriers (LOHC), hydrogen storage/release and CO2 conversion. A compact reactor with neatly drawn tubing, a couple of catalyst-granule jars, paired small sphere molecular icons for hydrogen and a simple three-sphere linear CO2 model, with a leaf motif suggesting carbon-resource conversion. These are thematic illustrations, not scientific schematics. One hand holds a sealed small vial with pale turquoise liquid. No equipment logos or words.
Composition: waist-up portrait, head and face centered in the upper half, enough space around the hair and goggles for cropping to a card, reduced background detail so the character reads at thumbnail size. Keep an illustrated teal/green background and a few warm gold highlights, with a subtle pale lavender accent to distinguish this person from Hong.
Avoid: photo texture, skin pores, lens blur, hyperrealism, glossy realistic 3D rendering, giant anime eyes, male identity from image 2, round glasses, suit and tie, awards or Nobel emblems, brand logos, text, watermark, extra people or extra fingers.
```

