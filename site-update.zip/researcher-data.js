/* User-supplied professional CV; original CV/photo are not published. */
window.SUSOMOON_RESEARCHERS = {
  "experts": [
    {
      "id": "hong-yoonki",
      "name": "홍윤기",
      "nameEn": "Yoon-Ki Hong",
      "collection": "researcher",
      "field": "chemistry",
      "specialty": "촉매 · 바이오매스 · 고분자 · 윤활기유",
      "year": "2010–2026",
      "era": "공개 연구 기록",
      "recognition": "촉매공학 · 소재·공정 공동 연구",
      "tagline": "촉매의 발견을, 소재와 공정으로.",
      "summary": "촉매공학과 바이오매스 전환을 연구하고, 올레핀·고분자·윤활기유 관련 공동발명에 참여한 연구자입니다. 제공 이력서의 논문 9편(제1저자 3편·공동저자 6편)과 대표 특허 문헌 19개 항목을 연결했습니다. 기관명은 해당 문헌의 출원인 정보이며 현재 소속을 의미하지 않습니다.",
      "tags": [
        "촉매",
        "바이오매스",
        "수첨탈산소",
        "NOx 저감",
        "올레핀",
        "고분자",
        "윤활기유",
        "폴리올에스테르"
      ],
      "achievements": [
        "구아이아콜 수첨탈산소와 리그닌 모델물질 전환 촉매를 공동 연구했습니다.",
        "질소산화물·암모니아·입자상물질 저감과 수성가스전이반응 촉매 연구에 참여했습니다.",
        "올레핀 올리고머화·고분자 물성 예측·블록 공중합체·냉동기유 베이스 오일의 공동발명에 참여했습니다."
      ],
      "papers": [
        {
          "title": "The catalytic activity of Sulfided Ni/W/TiO2 (anatase) for the hydrodeoxygenation of Guaiacol",
          "year": 2014,
          "authors": "Hong, Y. K.; Lee, D. W.; Eom, H. J.; Lee, K. Y.",
          "journal": "Journal of Molecular Catalysis A: Chemical 392, 241–246 (2014)",
          "doi": "10.1016/j.molcata.2014.05.025",
          "url": "https://doi.org/10.1016/j.molcata.2014.05.025",
          "summary": "리그닌 유래 바이오오일의 모델물질인 구아이아콜을 수첨탈산소하는 황화 Ni/W/TiO₂ 촉매를 공동 연구했습니다. 텅스텐층의 구조와 황화 상태가 촉매 활성에 미치는 영향을 다룹니다.",
          "roleLabel": "제1저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "The catalytic activity of Pd/WOx/γ-Al2O3 for hydrodeoxygenation of guaiacol",
          "year": 2014,
          "authors": "Hong, Y. K.; Lee, D. W.; Eom, H. J.; Lee, K. Y.",
          "journal": "Applied Catalysis B: Environmental 150–151, 438–445 (2014)",
          "doi": "10.1016/j.apcatb.2013.12.045",
          "url": "https://doi.org/10.1016/j.apcatb.2013.12.045",
          "summary": "Pd/WOx/γ-Al₂O₃ 촉매로 구아이아콜을 전환하는 공동 연구입니다. 표면 산성도와 금속·담체 상호작용에 따른 수첨탈산소 반응 특성을 살폈습니다.",
          "roleLabel": "제1저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "Passive NOx Reduction with CO Using Pd/TiO2/Al2O3 + WGSR Catalysts Under Simulated Post-Euro IV Diesel Exhaust Conditions",
          "year": 2010,
          "authors": "Hong, Y. K.; Lee, D. W.; Ko, Y. C.; Li, Y.; Han, H. S.; Lee, K. Y.",
          "journal": "Catalysis Letters 136, 106–115 (2010)",
          "doi": "10.1007/s10562-010-0312-5",
          "url": "https://doi.org/10.1007/s10562-010-0312-5",
          "summary": "디젤 배기가스를 모사한 조건에서 Pd 촉매와 수성가스전이반응(WGSR) 촉매를 결합해 CO에 의한 질소산화물(NOx) 저감을 연구했습니다.",
          "roleLabel": "제1저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "Zirconia catalysts (ZrO2 and Na-ZrO2) for the conversion of phenethyl phenyl ether (PPE) in supercritical water",
          "year": 2015,
          "authors": "Eom, H. J.; Kim, M. S.; Lee, D. W.; Hong, Y. K.; Jeong, G.; Lee, K. Y.",
          "journal": "Applied Catalysis A: General 493, 149–157 (2015)",
          "doi": "10.1016/j.apcata.2014.12.052",
          "url": "https://doi.org/10.1016/j.apcata.2014.12.052",
          "summary": "초임계수에서 리그닌 모델물질인 페네틸 페닐 에테르(PPE)를 전환하는 지르코니아 촉매를 공동 연구했습니다.",
          "roleLabel": "공동저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "Effects of a sodium carbonate (Na2CO3) additive on the conversion of phenethyl phenyl ether (PPE) in high-temperature water",
          "year": 2014,
          "authors": "Eom, H. J.; Lee, D. W.; Hong, Y. K.; Chung, S. H.; Seo, M. G.; Lee, K. Y.",
          "journal": "Applied Catalysis A: General 472, 152–159 (2014)",
          "doi": "10.1016/j.apcata.2013.12.007",
          "url": "https://doi.org/10.1016/j.apcata.2013.12.007",
          "summary": "고온수에서 리그닌 모델물질 PPE의 전환에 탄산나트륨 첨가가 미치는 영향을 공동 연구했습니다.",
          "roleLabel": "공동저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "Oxidation of ammonia to nitrogen over Pt/Fe/ZSM5 catalyst: Influence of catalyst support on the low temperature activity",
          "year": 2012,
          "authors": "Kim, M. S.; Lee, D. W.; Chung, S. H.; Hong, Y. K.; Lee, S. H.; Oh, S. H.; Cho, I. H.; Lee, K. Y.",
          "journal": "Journal of Hazardous Materials 237–238, 153–160 (2012)",
          "doi": "10.1016/j.jhazmat.2012.08.026",
          "url": "https://doi.org/10.1016/j.jhazmat.2012.08.026",
          "summary": "Pt/Fe/ZSM5 촉매를 이용해 암모니아를 질소로 산화하는 반응에서 담체가 저온 활성에 미치는 영향을 공동 연구했습니다.",
          "roleLabel": "공동저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "The CO removal performances of Cr-free Fe/Ni catalysts for high temperature WGSR under LNG reformate condition without additional steam",
          "year": 2011,
          "authors": "Lee, J. Y.; Lee, D. W.; Hong, Y. K.; Lee, K. Y.",
          "journal": "International Journal of Hydrogen Energy 36(14), 8173–8180 (2011)",
          "doi": "10.1016/j.ijhydene.2011.03.164",
          "url": "https://doi.org/10.1016/j.ijhydene.2011.03.164",
          "summary": "추가 수증기 없이 LNG 개질가스 조건에서 작동하는 크롬 비함유 Fe/Ni 촉매의 고온 수성가스전이반응과 CO 제거 성능을 공동 연구했습니다.",
          "roleLabel": "공동저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "The enhancement of low-temperature combustion of diesel PM through concerted application of FBC and perovskite",
          "year": 2010,
          "authors": "Lee, D. W.; Sung, J. Y.; Park, J. H.; Hong, Y. K.; Lee, S. H.; Oh, S. H.; Lee, K. Y.",
          "journal": "Catalysis Today 157(1–4), 432–435 (2010)",
          "doi": "10.1016/j.cattod.2010.02.047",
          "url": "https://doi.org/10.1016/j.cattod.2010.02.047",
          "summary": "연료 첨가 촉매(FBC)와 페로브스카이트의 병용으로 디젤 입자상물질(PM)의 저온 연소를 촉진하는 연구에 참여했습니다.",
          "roleLabel": "공동저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        },
        {
          "title": "Influence of Pd precursors on Pd/TiO2/Al2O3 catalysts for lean NOx reduction with CO and H2",
          "year": 2010,
          "authors": "Li, Y.; Lee, D. W.; Hong, Y. K.; Kim, S. M.; Han, H. S.; Lee, K. Y.",
          "journal": "Reaction Kinetics, Mechanisms and Catalysis 99, 361–369 (2010)",
          "doi": "10.1007/s11144-009-0132-z",
          "url": "https://doi.org/10.1007/s11144-009-0132-z",
          "summary": "Pd 전구체의 차이가 Pd/TiO₂/Al₂O₃ 촉매의 CO·H₂ 기반 희박 조건 NOx 환원에 미치는 영향을 공동 연구했습니다.",
          "roleLabel": "공동저자 논문",
          "summaryBasis": "제공 이력서의 서지·연구 설명을 바탕으로 정리한 요약"
        }
      ],
      "patents": [
        {
          "number": "KR101436429B1",
          "title": "귀금속이 담지된 촉매를 사용하여 리그닌 전환 물질로부터 고리모양 탄화수소를 생성하는 방법",
          "year": 2014,
          "publicationDate": "2014-09-01",
          "publicationType": "등록공보",
          "assignee": "고려대학교 산학협력단",
          "inventors": "이관영, 홍윤기, 엄희준, 이대원",
          "summary": "귀금속과 텅스텐 또는 몰리브덴 산화물을 포함한 알루미나 담지 촉매로 리그닌 유래 물질을 고리모양 탄화수소로 전환하는 공동발명입니다.",
          "url": "https://patents.google.com/patent/KR101436429B1/en",
          "statusNote": "고려대학교 산학협력단 · 등록공보 2014-09-01. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR101336981B1",
          "title": "텅스텐 산화물 티타니아 촉매를 사용하여 구아이아콜의 수첨탈산소 반응을 통해 카테콜 및 페놀 등 방향족 화합물을 생성하는 방법",
          "year": 2013,
          "publicationDate": "2013-12-04",
          "publicationType": "등록공보",
          "assignee": "고려대학교 산학협력단",
          "inventors": "이관영, 엄희준, 정상호, 홍윤기",
          "summary": "티타니아 담체, 니켈 또는 코발트 조촉매 및 황화 처리를 활용한 구아이아콜 수첨탈산소 전환의 공동발명입니다.",
          "url": "https://patents.google.com/patent/KR101336981B1/en",
          "statusNote": "고려대학교 산학협력단 · 등록공보 2013-12-04. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR101336982B1",
          "title": "텅스텐 산화물 알루미나 촉매를 사용하여 구아이아콜의 수첨탈산소 반응을 통해 카테콜 및 페놀 등 방향족 화합물을 생성하는 방법",
          "year": 2013,
          "publicationDate": "2013-12-04",
          "publicationType": "등록공보",
          "assignee": "고려대학교 산학협력단",
          "inventors": "이관영, 홍윤기, 엄희준, 정상호",
          "summary": "니켈 또는 코발트를 포함한 텅스텐 산화물 알루미나 촉매로 구아이아콜을 방향족 화합물로 전환하는 공동발명입니다.",
          "url": "https://patents.google.com/patent/KR101336982B1/en",
          "statusNote": "고려대학교 산학협력단 · 등록공보 2013-12-04. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "US10688482B2",
          "title": "올레핀 올리고머화 방법",
          "year": 2020,
          "publicationDate": "2020-06-23",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "Yoon Ki Hong, Yong Ho Lee, Eun Ji Shin, Ki Soo Lee, Jin Young Park, Seok Pil SA, Seul Ki IM",
          "summary": "연속교반탱크 반응기에서 올레핀과 용매의 공급 유량비를 제어하는 올리고머화 공정.",
          "application": "출원 US15/544,236  |  출원일 2016-02-05",
          "url": "https://patents.google.com/patent/US10688482B2/en",
          "statusNote": "LG화학 · 등록공보 2020-06-23. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR20160123213A",
          "title": "올레핀 올리고머의 연속 제조 방법",
          "year": 2016,
          "publicationDate": "2016-10-25",
          "publicationType": "출원공개",
          "assignee": "LG화학",
          "inventors": "홍윤기, 신은지, 사석필, 이기수, 이용호, 박진영, 임슬기",
          "summary": "올레핀 올리고머를 연속적으로 제조하는 공정.",
          "application": "출원 KR1020150173236A  |  출원일 2015-12-07",
          "url": "https://patents.google.com/patent/KR20160123213A/en",
          "statusNote": "LG화학 · 출원공개 2016-10-25. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR101757370B1",
          "title": "1-옥텐 조성물",
          "year": 2017,
          "publicationDate": "2017-07-12",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "이용호, 사석필, 신은지, 이기수, 박진영, 임슬기, 홍윤기",
          "summary": "1-옥텐 조성물 관련 기술.",
          "application": "출원 KR1020150125688A  |  출원일 2015-09-04",
          "url": "https://patents.google.com/patent/KR101757370B1/en",
          "statusNote": "LG화학 · 등록공보 2017-07-12. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "US10173948B2",
          "title": "올레핀 올리고머화 방법",
          "year": 2019,
          "publicationDate": "2019-01-08",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "Seul Ki IM, Yong Ho Lee, Eun Ji Shin, Ki Soo Lee, Jin Young Park, Seok Pil SA, Yoon Ki Hong",
          "summary": "활성 조절제를 포함한 촉매계를 사용하는 올레핀 올리고머화 기술.",
          "application": "출원 US15/738,068  |  출원일 2016-08-16",
          "url": "https://patents.google.com/patent/US10173948B2/en",
          "statusNote": "LG화학 · 등록공보 2019-01-08. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR102058142B1",
          "title": "리간드 화합물 및 올레핀 올리고머화 촉매계",
          "year": 2019,
          "publicationDate": "2019-12-20",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "이용호, 임슬기, 신은지, 이기수, 박진영, 사석필, 홍윤기",
          "summary": "리간드 화합물, 이를 포함하는 촉매계 및 올레핀 올리고머화 방법.",
          "application": "출원 KR1020150124380A  |  출원일 2015-09-02",
          "url": "https://patents.google.com/patent/KR102058142B1/en",
          "statusNote": "LG화학 · 등록공보 2019-12-20. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR101982789B1",
          "title": "리간드·유기 크롬 화합물 및 올레핀 올리고머화 촉매계",
          "year": 2019,
          "publicationDate": "2019-05-27",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "임슬기, 이용호, 이기수, 신은지, 박진영, 사석필, 홍윤기",
          "summary": "리간드와 유기 크롬 화합물을 이용하는 올리고머화 촉매 기술.",
          "application": "출원 KR1020150172686A  |  출원일 2015-12-04",
          "url": "https://patents.google.com/patent/KR101982789B1/en",
          "statusNote": "LG화학 · 등록공보 2019-05-27. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR102068795B1",
          "title": "고분자의 물성 예측 방법 — 장기 안정성",
          "year": 2020,
          "publicationDate": "2020-01-21",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "홍윤기, 권혁주, 송은경, 홍대식, 이예진, 김중수, 신은영, 유영석, 이기수",
          "summary": "분자량 분포 곡선을 활용한 고분자 장기 안정성 예측. 미국 대응 공보: US10634605B2.",
          "application": "출원 KR1020160157723A  |  출원일 2016-11-24",
          "url": "https://patents.google.com/patent/KR102068795B1/en",
          "statusNote": "LG화학 · 등록공보 2020-01-21. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR102095523B1",
          "title": "고분자의 물성 예측 방법 — 가공성",
          "year": 2020,
          "publicationDate": "2020-03-31",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "홍윤기, 권혁주, 송은경, 홍대식, 이예진, 김중수, 신은영, 유영석, 이기수",
          "summary": "분자량 분포 곡선을 활용한 고분자 가공성 예측. 미국 대응 공보: US10962522B2.",
          "application": "출원 KR1020160157724A  |  출원일 2016-11-24",
          "url": "https://patents.google.com/patent/KR102095523B1/en",
          "statusNote": "LG화학 · 등록공보 2020-03-31. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR102215024B1",
          "title": "폴리올레핀의 제조 방법",
          "year": 2021,
          "publicationDate": "2021-02-09",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "권혁주, 홍윤기, 송은경, 홍대식, 이예진, 김중수, 신은영, 유영석, 이기수",
          "summary": "고분자량과 내응력 균열성을 갖는 폴리올레핀 제조 기술.",
          "application": "출원 KR1020160162034A  |  출원일 2016-11-30",
          "url": "https://patents.google.com/patent/KR102215024B1/en",
          "statusNote": "LG화학 · 등록공보 2021-02-09. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "EP3476870B1",
          "title": "올레핀 중합체의 제조 방법",
          "year": 2026,
          "publicationDate": "2026-01-28",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "Joong Soo Kim, Eun Kyoung Song, Nak-Kyu SONG, Dae Sik Hong, Si Yong Kim, Eun Young Shin, Young Suk You, Yoon Ki Hong",
          "summary": "유럽 등록공보 명칭: Method for preparing an olefin polymer.",
          "application": "출원 EP17890923.0A  |  출원일 2017-12-06",
          "url": "https://patents.google.com/patent/EP3476870B1/en",
          "statusNote": "LG화학 · 등록공보 2026-01-28. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR102521452B1",
          "title": "파라핀 혼합물 및 이의 제조 방법",
          "year": 2023,
          "publicationDate": "2023-04-13",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "홍윤기, 신은지, 사석필, 이정석, 이기수",
          "summary": "황 및 방향족 함량이 낮은 파라핀 혼합물과 그 제조 기술.",
          "application": "출원 KR1020180135448A  |  출원일 2018-11-06",
          "url": "https://patents.google.com/patent/KR102521452B1/en",
          "statusNote": "LG화학 · 등록공보 2023-04-13. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "EP3747920A1",
          "title": "블록 공중합체 조성물 — 열분해 특성",
          "year": 2020,
          "publicationDate": "2020-12-09",
          "publicationType": "출원공개",
          "assignee": "LG화학",
          "inventors": "Hyun Mo Lee, Eun Ji Shin, Seok Pil Sa, Yoon Ki Hong, Ki Soo Lee, Bun Yeoul Lee",
          "summary": "폴리올레핀계·폴리스티렌계 블록을 포함하는 이중·삼중 블록 공중합체 조성물.",
          "application": "출원 EP19776148.9A  |  출원일 2019-03-29",
          "url": "https://patents.google.com/patent/EP3747920A1/en",
          "statusNote": "LG화학 · 출원공개 2020-12-09. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "EP3747922A1",
          "title": "블록 공중합체 조성물 — 가공성",
          "year": 2020,
          "publicationDate": "2020-12-09",
          "publicationType": "출원공개",
          "assignee": "LG화학",
          "inventors": "Yoon Ki Hong, Seok Pil Sa, Hyun Mo Lee, Eun Ji Shin, Ki Soo Lee, Bun Yeoul Lee",
          "summary": "분자량, 분산도, 유리전이온도 및 용융지수 조건을 갖는 블록 공중합체 조성물.",
          "application": "출원 EP19778223.8A  |  출원일 2019-03-29",
          "url": "https://patents.google.com/patent/EP3747922A1/en",
          "statusNote": "LG화학 · 출원공개 2020-12-09. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "EP3747921B1",
          "title": "블록 공중합체 조성물",
          "year": 2023,
          "publicationDate": "2023-12-06",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "Eun Ji Shin, Ki Soo Lee, Seok Pil Sa, Yoon Ki Hong, Bun Yeoul Lee",
          "summary": "유럽 등록공보 명칭: Block copolymer composition.",
          "application": "출원 EP19776273.5A  |  출원일 2019-03-29",
          "url": "https://patents.google.com/patent/EP3747921B1/en",
          "statusNote": "LG화학 · 등록공보 2023-12-06. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "EP3750931B1",
          "title": "블록 공중합체 조성물의 제조 방법",
          "year": 2023,
          "publicationDate": "2023-12-06",
          "publicationType": "등록공보",
          "assignee": "LG화학",
          "inventors": "Seok Pil Sa, Eun Ji Shin, Yoon Ki Hong, Hyun Mo Lee, Ki Soo Lee, Bun Yeoul Lee",
          "summary": "유럽 등록공보 명칭: Method for producing block copolymer composition.",
          "application": "출원 EP19775609.1A  |  출원일 2019-03-29",
          "url": "https://patents.google.com/patent/EP3750931B1/en",
          "statusNote": "LG화학 · 등록공보 2023-12-06. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        },
        {
          "number": "KR102958116B1",
          "title": "냉동기유용 폴리올에스테르계 베이스 오일 및 이의 제조방법",
          "year": 2026,
          "publicationDate": "2026-04-27",
          "publicationType": "등록공보",
          "assignee": "GS칼텍스",
          "inventors": "최인창, 김동신, 정다솔, 정상철, 홍윤기",
          "summary": "펜타에리스리톨·디펜타에리스리톨과 C4–C12 지방산을 활용한 냉동기유 베이스 오일.",
          "application": "출원 KR1020230174939A  |  출원일 2023-12-05",
          "url": "https://patents.google.com/patent/KR102958116B1/en",
          "statusNote": "GS칼텍스 · 등록공보 2026-04-27. 공동발명 문헌이며 현재 소속·권리 존속·독립 발명 수를 뜻하지 않습니다."
        }
      ],
      "works": [],
      "sourceUrl": "https://doi.org/10.1016/j.apcatb.2013.12.045",
      "sourceLabel": "대표 수첨탈산소 논문 확인",
      "sourceNote": "제공 이력서 기반 · 논문 DOI 및 특허 공보 연결 · 2026-09-21 반영",
      "patentNote": "19개는 이력서에 수록된 대표 공보 항목 수입니다. 전체 보유 특허 수나 독립 발명 수가 아니며, 해외 대응 공보를 별도로 더하지 않았습니다.",
      "portraitNote": "제공 사진을 바탕으로 얼굴 특징을 살린 AI 캐리커처입니다. 실험실과 소품은 연구 분야를 표현한 창작 배경입니다.",
      "portrait": "assets/hong-yoonki.png",
      "color": "#4e9a86"
    }
  ],
  "links": [
    {
      "source": "hong-yoonki",
      "target": "sharpless",
      "label": "촉매로 반응 경로 설계",
      "kind": "concept",
      "explanation": "홍윤기의 수첨탈산소 촉매 연구와 샤플리스의 선택적 화학반응 연구를 촉매·반응 설계 관점에서 잇는 개념 연결입니다. 같은 반응을 연구했거나 실제로 협업했다는 의미는 아닙니다.",
      "sourceUrl": "https://doi.org/10.1016/j.apcatb.2013.12.045",
      "sourceUrls": [
        "https://doi.org/10.1016/j.apcatb.2013.12.045",
        "https://www.nobelprize.org/prizes/chemistry/2022/sharpless/facts/"
      ]
    },
    {
      "source": "hong-yoonki",
      "target": "taikyue-ree",
      "label": "분자 특성과 물성의 해석",
      "kind": "concept",
      "explanation": "고분자 분자량 분포를 활용한 물성 예측 공동발명과 이태규의 물성 이론을 물질의 특성 해석 관점에서 잇는 개념 연결입니다. 이론의 직접 적용이나 공동연구 관계를 뜻하지 않습니다.",
      "sourceUrl": "https://patents.google.com/patent/KR102068795B1/en"
    },
    {
      "source": "hong-yoonki",
      "target": "einstein",
      "label": "냉동 기술과 소재",
      "kind": "concept",
      "explanation": "홍윤기의 냉동기유 베이스 오일 공동발명과 아인슈타인의 냉동장치 공동발명을 냉동 기술이라는 응용 주제로 잇는 개념 연결입니다. 장치 구조나 기술 계승·협업 관계가 같다는 뜻은 아닙니다.",
      "sourceUrl": "https://patents.google.com/patent/KR102958116B1/en",
      "sourceUrls": [
        "https://patents.google.com/patent/KR102958116B1/en",
        "https://patents.google.com/patent/US1781541A/en"
      ]
    }
  ]
};
