export function installResearchDesk({root,experts,links,meta,esc,onOpen,onMatch,toast}){
 const engine=window.SusomoonResearch;let query='',kind='all',selected=[],visible=null,downloadUrl='';
 root.innerHTML=`<div class="research-heading"><div><span class="eyebrow">H₂ RESEARCH DESK</span><h2>근거를 찾고, 질문을 준비하세요.</h2></div><span class="research-mode">공개 자료 탐색 체험</span></div><p class="research-intro">왜 이 연구자인지 확인하고, 최대 3명의 연구 관점을 질문서에 담아보세요.</p><div class="evidence-filters" role="group" aria-label="추천 근거 유형"><button data-evidence="all" aria-pressed="true">모든 근거</button><button data-evidence="paper" aria-pressed="false">논문</button><button data-evidence="patent" aria-pressed="false">특허 문헌</button><button data-evidence="work" aria-pressed="false">저술·대표 업적</button></div><p class="research-scope"></p><p class="research-gaps" role="status"></p><div class="research-grid"><div><h3 class="research-count"></h3><div class="evidence-results"></div></div><aside class="question-workbench"><span class="eyebrow">FROM DISCOVERY TO DIALOGUE</span><h3>나의 연구 질문서 <span class="selection-count">0 / 3</span></h3><div class="selected-experts"></div><div class="complementary-experts"></div><label>이번 상담에서 얻고 싶은 것<input class="brief-objective" maxlength="600" placeholder="예: 후보 반응의 선택 기준 정리"></label><label>실험 맥락·이미 시도한 것<textarea class="brief-context" maxlength="1200" placeholder="예: 대상 물질, 관찰 결과, 일정 등"></textarea></label><button class="primary-button create-brief" disabled>질문서 만들기 ↗</button><p class="workbench-note">공개 과학자는 연구 관점 비교용입니다. 질문서는 이 화면에서만 작성되며 자동 전송·저장되지 않습니다.</p><div class="brief-output" hidden><label>질문서 미리보기<textarea class="brief-preview" readonly rows="12"></textarea></label><a class="secondary-button download-brief" download="susomoon-research-brief.txt">질문서 파일 저장 ↓</a><button class="secondary-button copy-brief">질문서 복사</button></div></aside></div><p class="research-footnote">자료·주제 일치로 추천합니다. 수소·구매·꾸미기는 순위에 영향을 주지 않습니다. 특허 문헌 연결은 권리 상태 판단이 아닙니다.</p>`;
 const $=s=>root.querySelector(s),$$=s=>[...root.querySelectorAll(s)];
 function toggle(id){
  if(selected.includes(id))selected=selected.filter(x=>x!==id);
  else if(selected.length===3){toast('질문서에는 최대 3명의 관점을 담을 수 있어요.');return;}
  else selected.push(id);
  $('.brief-output').hidden=true;render();
 }
 function render(){
  const a=engine.analyze(experts,query,kind),rows=a.results.filter(r=>visible===null||visible.has(r.e.id));
  $('.research-scope').textContent=`인식한 주제: ${a.recognized.join(' · ')||'이름·입력 키워드'} · 자료 검토 ${meta.factsCheckedAt} · 규칙 기반 탐색`;
  $('.research-gaps').textContent=a.gaps.length?`추가 확인 필요: ${a.gaps.join(' · ')} — 현재 선택한 자료 유형에서 직접 일치하는 문헌을 찾지 못했습니다. 관련 관점은 답변이 아닌 탐색 단서입니다.`:'문헌의 키워드 일치는 적용 가능성이나 정답을 보장하지 않습니다. 원문과 실험 조건을 함께 확인하세요.';
  $('.research-count').textContent=`근거와 함께 살펴볼 연구자 ${rows.length}명`;
  $('.evidence-results').innerHTML=rows.length?rows.map(r=>{
   const e=r.e,records=r.evidence.length?r.evidence:r.records;
   return `<article class="evidence-card result-row" data-expert="${esc(e.id)}"><div class="evidence-person"><img src="${esc(e.thumbnail)}" alt=""><div><h4>${esc(e.name)}</h4><p>${esc(e.specialty)}</p></div><button data-open="${esc(e.id)}" aria-label="${esc(e.name)} 카드 보기">카드 ↗</button></div><div class="match-reason"><span>${r.exact?'이름 일치':r.matchedRecords.length?'자료 내용 일치':'프로필·확장어 일치'}</span><p>${esc(r.reason.join(' · '))}</p></div><div class="evidence-links">${records.slice(0,2).map(p=>`<a href="${esc(p.url)}" target="_blank" rel="noopener noreferrer"><small>${esc(p.label)} · ${esc(p.year||'연도 미상')}${p.hits?.length?' · '+esc(p.hits.join(' / ')):' · 대표 자료'}</small><strong>${esc(p.title)} ↗</strong></a>`).join('')||'<p>연결된 자료가 아직 없습니다.</p>'}</div>${!r.evidence.length?'<p class="evidence-limit">위 대표 자료와 질문의 직접 일치는 미확인입니다.</p>':''}<button class="select-perspective" data-select="${esc(e.id)}" aria-pressed="${selected.includes(e.id)}">${selected.includes(e.id)?'✓ 질문서에 담음 · 빼기':'＋ '+esc(e.name)+' 관점 담기'}</button></article>`;
  }).join(''):'<div class="research-empty"><strong>이 조건에 맞는 근거가 아직 없어요.</strong><p>자료 유형이나 전공 필터를 바꾸거나 다른 질문으로 탐색해 보세요. 연구자가 해당 업적을 갖지 않았다는 뜻은 아닙니다.</p></div>';
  $('.selection-count').textContent=selected.length+' / 3';
  $('.selected-experts').innerHTML=selected.length?selected.map(id=>{const e=experts.find(x=>x.id===id);return `<div><img src="${esc(e.thumbnail)}" alt=""><span>${esc(e.name)}<small>${esc(e.specialty)}</small></span><button data-remove="${esc(id)}" aria-label="${esc(e.name)} 관점 빼기">×</button></div>`;}).join(''):'<p>왼쪽에서 연구 관점을 담아주세요.</p>';
  const candidates=engine.complements(experts,links,selected);
  $('.complementary-experts').innerHTML=candidates.length?`<h4>함께 살펴볼 보완 관점</h4><p>편집한 개념 연결 · 실제 협업 관계 아님</p>`+candidates.map(({e,from,link})=>`<details><summary>${esc(e.name)} · ${esc(link.label)}</summary><p>${esc(from.name)}에서 이어지는 관점<br>${esc(link.explanation)}</p><a href="${esc(engine.safeUrl(link.sourceUrl))}" target="_blank" rel="noopener noreferrer">연결 출처 ↗</a><button data-select="${esc(e.id)}">＋ ${esc(e.name)} 관점 담기</button></details>`).join(''):'';
  $('.create-brief').disabled=!selected.length;
  $$('[data-open]').forEach(b=>b.onclick=()=>onOpen(b.dataset.open));
  $$('[data-select]').forEach(b=>b.onclick=()=>toggle(b.dataset.select));
  $$('[data-remove]').forEach(b=>b.onclick=()=>toggle(b.dataset.remove));
 }
 $$('[data-evidence]').forEach(b=>b.onclick=()=>{kind=b.dataset.evidence;$$('[data-evidence]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));$('.brief-output').hidden=true;onMatch(engine.rank(experts,query,kind).map(r=>r.e.id));});
 const makeBrief=()=>engine.brief({experts,links,query,selectedIds:selected,objective:$('.brief-objective').value,context:$('.brief-context').value,kind,checkedAt:meta.factsCheckedAt});
 $('.create-brief').onclick=()=>{const text=makeBrief();$('.brief-preview').value=text;if(downloadUrl)URL.revokeObjectURL(downloadUrl);downloadUrl=URL.createObjectURL(new Blob(['\ufeff'+text],{type:'text/plain;charset=utf-8'}));$('.download-brief').href=downloadUrl;$('.brief-output').hidden=false;$('.brief-preview').focus();$('.brief-preview').setSelectionRange(0,0);};
 ['.brief-objective','.brief-context'].forEach(s=>$(s).oninput=()=>{$('.brief-output').hidden=true;});
 $('.download-brief').onclick=()=>toast('파일 저장이 제한된 브라우저에서는 질문서 복사를 이용해 주세요.');
 $('.copy-brief').onclick=async()=>{try{await navigator.clipboard.writeText(makeBrief());toast('질문서를 복사했어요.');}catch{const p=$('.brief-preview');p.focus();p.select();toast('질문서 전체를 선택했어요. 복사 메뉴를 이용해 주세요.');}};
 return {show(value){query=value;kind='all';selected=[];visible=null;$('.brief-objective').value='';$('.brief-context').value='';$('.brief-output').hidden=true;$$('[data-evidence]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.evidence==='all')));root.hidden=false;render();},filter(ids){visible=ids;if(!root.hidden)render();},clear(){root.hidden=true;selected=[];query='';}};
}
