/* Personal prototype records. Never an organization-wide verification authority. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.SusomoonKnowledge=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const KEY='susomoon-knowledge-v1',REVIEW_DAYS=90,DAY=86400000;
 const clone=x=>JSON.parse(JSON.stringify(x)),plain=x=>x&&typeof x==='object'&&!Array.isArray(x);
 const clean=(x,max)=>typeof x==='string'?x.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g,'').trim().slice(0,max):'';
 const iso=x=>typeof x==='string'&&Number.isFinite(Date.parse(x))?new Date(x).toISOString():'';
 const url=x=>{try{const u=new URL(x);return u.protocol==='https:'?u.href:'';}catch{return '';}};
 // Store the compared content, not a probabilistic hash, to detect source edits.
 const signature=r=>JSON.stringify([r.kind||'',r.title||'',r.summary||'',url(r.url),r.year||'']);
 const STATES=['preparing','reviewing','resolved'];
 function sourceRefs(value){return (Array.isArray(value)?value:[]).filter(plain).map(r=>({url:url(r.url),title:clean(r.title,500),kind:clean(r.kind,30)})).filter(r=>r.url&&r.title).filter((r,i,a)=>a.findIndex(x=>x.url===r.url)===i).slice(0,12);}
 function sanitize(raw){
  const state={version:1,reviews:[],notes:[]};if(!plain(raw)||raw.version!==1)return state;
  for(const r of Array.isArray(raw.reviews)?raw.reviews.slice(-500):[]){
   if(!plain(r)||!url(r.url)||!['checked','flagged'].includes(r.status)||!iso(r.at)||typeof r.signature!=='string'||r.signature.length>16000)continue;
   const entry={url:url(r.url),status:r.status,at:iso(r.at),signature:r.signature};state.reviews=state.reviews.filter(x=>x.url!==entry.url);state.reviews.push(entry);
  }
  for(const n of Array.isArray(raw.notes)?raw.notes.slice(-100):[]){
   if(!plain(n)||!/^note-[a-z0-9-]{3,100}$/.test(n.id)||!clean(n.query,500)||!iso(n.createdAt)||!iso(n.updatedAt))continue;
   const outcome=clean(n.outcome,2500);let status=STATES.includes(n.status)?n.status:'preparing';if(status==='resolved'&&outcome.length<10)status='reviewing';
   const entry={id:n.id,query:clean(n.query,500),objective:clean(n.objective,600),context:clean(n.context,1200),expertIds:[...new Set((Array.isArray(n.expertIds)?n.expertIds:[]).filter(x=>typeof x==='string'&&/^[a-z0-9-]{1,100}$/.test(x)))].slice(0,3),sources:sourceRefs(n.sources),outcome,status,createdAt:iso(n.createdAt),updatedAt:iso(n.updatedAt)};
   state.notes=state.notes.filter(x=>x.id!==entry.id);state.notes.push(entry);
  }
  return state;
 }
 function reviewStatus(record,reviews,catalogDate,now=Date.now()){
  const own=(reviews||[]).find(x=>x.url===url(record.url));
  if(own?.status==='flagged')return {state:'flagged',label:'내 검토 · 재확인 필요',allowed:false,at:own.at};
  if(own&&own.signature!==signature(record))return {state:'changed',label:'자료 변경 · 재검토 필요',allowed:false,at:own.at};
  const stamp=own?.at||(catalogDate?catalogDate+'T00:00:00Z':''),time=Date.parse(stamp);
  if(!Number.isFinite(time)||time>now+DAY)return {state:'unreviewed',label:'검토일 미확인',allowed:false,at:''};
  if(now-time>REVIEW_DAYS*DAY)return {state:'due',label:'90일 경과 · 재검토 필요',allowed:false,at:stamp};
  return own?{state:'checked',label:'내 검토 · 확인 기록',allowed:true,at:stamp}:{state:'catalog',label:'카탈로그 출처 검토',allowed:true,at:stamp};
 }
 function createStore(storage,{now=()=>Date.now(),newId=()=>`note-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`}={}){
  let state={version:1,reviews:[],notes:[]};try{const raw=storage?.getItem(KEY);if(raw&&raw.length<=5000000)state=sanitize(JSON.parse(raw));}catch{}
  function commit(next,value){try{if(storage)storage.setItem(KEY,JSON.stringify(next));}catch{return {ok:false,error:'저장 공간이 부족하거나 저장이 제한됐습니다. 내용을 복사해 보관해 주세요.'};}state=next;return {ok:true,...value};}
  const stamp=()=>new Date(now()).toISOString();
  return {
   persistent:!!storage,getState:()=>clone(state),
   review(record,status){if(!url(record?.url)||!['checked','flagged','reset'].includes(status))return {ok:false,error:'검토 항목이 올바르지 않습니다.'};const next=clone(state);next.reviews=next.reviews.filter(x=>x.url!==url(record.url));if(status!=='reset')next.reviews.push({url:url(record.url),signature:signature(record),status,at:stamp()});if(next.reviews.length>500)return {ok:false,error:'검토 기록은 최대 500개까지 저장할 수 있어요.'};return commit(next,{});},
   saveNote(input){
    if(!plain(input)||!clean(input.query,500))return {ok:false,error:'질문을 먼저 입력해 주세요.'};
    const next=clone(state),id=input.id||newId(),found=next.notes.find(n=>n.id===id);
    if(input.id&&!found)return {ok:false,error:'연구 노트를 찾지 못했습니다.'};
    if(!input.id&&found)return {ok:false,error:'노트 식별자가 겹쳤습니다. 다시 저장해 주세요.'};
    if(!found&&next.notes.length>=100)return {ok:false,error:'연구 노트는 최대 100개까지 보관할 수 있어요.'};
    const n=sanitize({version:1,notes:[{...input,id,createdAt:found?.createdAt||stamp(),updatedAt:stamp(),status:found?.status||'preparing',outcome:found?.outcome||''}]}).notes[0];
    if(!n)return {ok:false,error:'연구 노트 형식이 올바르지 않습니다.'};
    next.notes=next.notes.filter(x=>x.id!==id);next.notes.push(n);return commit(next,{id});
   },
   updateNote(id,{status,outcome}){
    const next=clone(state),n=next.notes.find(x=>x.id===id);if(!n||!STATES.includes(status))return {ok:false,error:'연구 노트 상태가 올바르지 않습니다.'};
    const text=clean(outcome,2500);if(status==='resolved'&&text.length<10)return {ok:false,error:'정리 완료로 표시하려면 알게 된 내용과 한계를 10자 이상 남겨주세요.'};
    n.status=status;n.outcome=text;n.updatedAt=stamp();return commit(next,{});
   }
  };
 }
 function noteText(note,experts){return ['수소문 · 나의 연구 노트',`질문: ${note.query}`,`목표: ${note.objective||'미작성'}`,`실험 맥락: ${note.context||'미작성'}`,`상태: ${{preparing:'준비 중',reviewing:'검토 중',resolved:'정리 완료'}[note.status]}`,'',`참고한 연구 관점: ${note.expertIds.map(id=>experts.find(e=>e.id===id)?.name||'자료에서 제외된 연구자').join(' · ')||'미선택'}`,...note.sources.map(r=>`${r.title}\n${r.url}`),'',`내가 정리한 내용: ${note.outcome||'미작성'}`,'개인 연구 기록이며 전문가의 답변·조직 승인 또는 검증된 사실을 의미하지 않습니다.'].join('\n');}
 return {KEY,REVIEW_DAYS,signature,sanitize,reviewStatus,createStore,noteText};
});
