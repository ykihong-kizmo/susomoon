(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.SusomoonPortrait=api;})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const KEY='susomoon-portrait-v1',MAX_LENGTH=700000;
  function validImage(value){return typeof value==='string'&&value.length>100&&value.length<=MAX_LENGTH&&/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value);}
  function clean(value){return value&&value.version===1&&validImage(value.image)&&['classic','watercolor'].includes(value.style)?{version:1,image:value.image,style:value.style}:null;}
  function createStore(storage){
    let current=null;
    try{current=clean(JSON.parse(storage?.getItem(KEY)||'null'));}catch(_){}
    return {
      get:()=>current?{...current}:null,
      save(value){const next=clean(value);if(!next)return {ok:false,message:'저장할 캐리커처 이미지를 확인해 주세요.'};
        try{if(storage)storage.setItem(KEY,JSON.stringify(next));}catch(_){return {ok:false,message:'저장 공간이 부족해요. 이미지를 내려받아 보관한 뒤 다시 시도해 주세요.'};}
        current=next;return {ok:true,persistent:!!storage};
      }
    };
  }
  return Object.freeze({createStore,validImage,MAX_LENGTH});
});
