import {hydrogenAudio} from './audio-engine.js';
import {installOrbitMotion} from './orbit-motion.js';
let orbitScene=null;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const {experts,links,meta}=window.SUSOMOON_DATA;
function availableBrowserStorage(){
 try {
  const storage=window.localStorage,key='susomoon-probe-'+Date.now()+'-'+Math.random().toString(36).slice(2);
  storage.setItem(key,key);
  const writable=storage.getItem(key)===key;
  storage.removeItem(key);
  return writable?storage:null;
 } catch (_) { return null; }
}
const browserStorage=availableBrowserStorage();
const store=window.SusomoonState.createStore(browserStorage);
function installDialogFallback(dialog){
 if(typeof dialog.showModal==='function'&&typeof dialog.close==='function')return;
 const shade=document.createElement('div');shade.className='dialog-fallback-shade';shade.hidden=true;
 document.body.appendChild(shade);dialog.classList.add('dialog-fallback');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');
 Object.defineProperty(dialog,'open',{configurable:true,get(){return dialog.hasAttribute('open');}});
 dialog.showModal=()=>{dialog.setAttribute('open','');shade.hidden=false;document.body.classList.add('dialog-fallback-open');$('#closeExpert').focus();};
 dialog.close=()=>{if(!dialog.open)return;dialog.removeAttribute('open');shade.hidden=true;document.body.classList.remove('dialog-fallback-open');dialog.dispatchEvent(new Event('close'));};
 shade.onclick=()=>dialog.close();
 dialog.addEventListener('keydown',e=>{
  if(e.key==='Escape'){e.preventDefault();dialog.close();return;}
  if(e.key!=='Tab')return;
  const focusable=$$('button,a[href],input,textarea,select,[tabindex]',dialog).filter(el=>!el.disabled&&el.tabIndex>=0&&el.getClientRects().length);
  const first=focusable[0],last=focusable[focusable.length-1];
  if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
  else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
 });
}
installDialogFallback($('#expertDialog'));
if(!browserStorage){const notice=document.createElement('p');notice.className='storage-notice';notice.setAttribute('role','status');notice.textContent='이 브라우저에서는 저장이 제한되어 임시 모드로 이용합니다. 프로필·방명록·수소는 페이지를 닫거나 새로고침하면 사라집니다.';$('#mainContent').prepend(notice);}
const byId=id=>experts.find(e=>e.id===id);
let selected=null,detailTab='research',filter='all',matched=null,scale=1,pan={x:0,y:0},fit=.8,searchTimer=0,searchGeneration=0,demoTimers=[],lastFocus=null;
hydrogenAudio.setEnabled(false);
const fieldLabels={all:'전체 분야',chemistry:'화학',physics:'물리학',life:'생명·의학',engineering:'공학·발명',mathematics:'수학',earth:'지리·천문'};
let groupFilter='all',positions={},graphSize={width:1000,height:620},collectionGroup='all';
const total=String(experts.length).padStart(3,'0');
const collectionLabel=e=>e.collection==='korea'?'KOREAN SCIENCE':'NOBEL LAUREATE';
const dateLabel=e=>e.collection==='korea'?(e.era||'한국 과학')+' · '+e.year:'NOBEL '+e.year;
function activeExperts(){return experts.filter(e=>(filter==='all'||e.field===filter)&&(groupFilter==='all'||e.collection===groupFilter)&&(matched===null||matched.includes(e.id)));}
const serial=e=>String(experts.indexOf(e)+1).padStart(3,'0');
function toast(text){$('#toast').textContent=text;$('#toast').classList.add('show');clearTimeout(searchTimer);searchTimer=setTimeout(()=>$('#toast').classList.remove('show'),3400);}
function changeView(view){$$('.view').forEach(v=>v.classList.toggle('active',v.id===view+'View'));$$('[data-view]').forEach(v=>v.classList.toggle('active',v.dataset.view===view));$('#breadcrumbTitle').textContent={explore:'지식 유니버스',collection:'전문가 컬렉션',mycard:'나의 연구자 카드',studio:'브랜드 스튜디오'}[view];if(view==='mycard')renderProfile();if(view==='explore')requestAnimationFrame(fitGraph);if(view!=='studio')$('#promoVideo').pause();window.scrollTo(0,0);}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>{stopDemo();changeView(b.dataset.view);}));
$('.brand').onclick=()=>changeView('explore');$('#profileShortcut').onclick=()=>changeView('mycard');$('#wallet').onclick=()=>{changeView('mycard');toast(`보유 수소 ${store.getState().balance} H₂ · 프로필 완성과 방명록으로 모을 수 있어요.`);};
$('#soundToggle').onclick=()=>{const on=!hydrogenAudio.enabled;hydrogenAudio.setEnabled(on);$('#soundToggle').classList.toggle('on',on);$('#soundToggle').setAttribute('aria-label',on?'효과음 끄기':'효과음 켜기');$('#soundToggle').title=on?'효과음 끄기':'효과음 켜기';if(on)hydrogenAudio.play('discovery');};
function renderGraph(){
 const visible=activeExperts(),layout=window.SusomoonGraph.layout(visible);positions=layout.positions;graphSize=layout;
 const world=$('#graphWorld');world.style.width=layout.width+'px';world.style.height=layout.height+'px';world.classList.toggle('overview',layout.overview);
 $('#edges').setAttribute('viewBox','0 0 '+layout.width+' '+layout.height);
 $('#nodes').innerHTML=visible.map(e=>{let [x,y,angle]=positions[e.id];return `<button class="graph-node" data-expert="${e.id}" style="left:${x}px;top:${y}px;--angle:${angle}deg;--node-color:${e.color}" aria-label="${e.name} 전문가 카드 보기"><div class="node-card"><img src="${e.thumbnail}" alt="${e.name}의 캐리커처와 연구 배경" draggable="false"><span class="node-tag">${collectionLabel(e)}</span><div class="node-title"><strong>${layout.overview&&e.collection==='nobel'?e.name.split(' ').slice(-1)[0]:e.name}</strong><small>${e.specialty}</small></div></div><div class="node-label"><i></i>${fieldLabels[e.field]||e.field}</div></button>`}).join('');
 $('#edges').innerHTML=links.map((l,i)=>{let a=positions[l.source],b=positions[l.target];if(!a||!b)return '';return `<g data-link="${i}"><line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}"/><text x="${(a[0]+b[0])/2}" y="${(a[1]+b[1])/2-6}" text-anchor="middle">${esc(l.label)}</text></g>`}).join('');
 $$('[data-expert]',$('#nodes')).forEach(b=>{b.onclick=()=>openExpert(b.dataset.expert);b.onmouseenter=()=>highlight(b.dataset.expert);b.onmouseleave=()=>highlight(null);b.onfocus=()=>highlight(b.dataset.expert);b.onblur=()=>highlight(null);});
 $('#graphCount').textContent=visible.length+' / '+experts.length+'명';$('#emptySearch').hidden=visible.length>0;fitGraph();if(orbitScene)orbitScene.refresh();
 const e=byId('jang-yeongsil')||byId('hodgkin');$('#featuredMini').innerHTML=`<img src="${e.thumbnail}" alt=""><div><small>EDITOR’S PICK</small><strong>${e.name}</strong><p>${esc(e.tagline)}</p></div><span>↗</span>`;$('#featuredMini').onclick=()=>openExpert(e.id);$('#featuredMini').setAttribute('role','button');$('#featuredMini').tabIndex=0;$('#featuredMini').onkeydown=ev=>{if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();openExpert(e.id);}};
}
function highlight(id){$$('[data-link]').forEach(g=>{$('line',g).classList.toggle('highlight',id&&[links[+g.dataset.link].source,links[+g.dataset.link].target].includes(id));});}
function applyFilter(){const visible=new Set(activeExperts().map(e=>e.id));renderGraph();const rows=$$('.result-row');if(rows.length){rows.forEach(row=>row.hidden=!visible.has(row.dataset.expert));$('#searchResults').hidden=matched===null||visible.size===0;const heading=$('h3',$('#searchResults'));if(heading)heading.textContent='검색 결과 '+visible.size+'명 · '+fieldLabels[filter]+' · 키워드 기반 추천';}}
$$('[data-filter]').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;$$('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));scale=1;pan={x:0,y:0};applyFilter();});
$$('[data-group]').forEach(b=>b.onclick=()=>{groupFilter=b.dataset.group;$$('[data-group]').forEach(x=>x.classList.toggle('active',x===b));scale=1;pan={x:0,y:0};applyFilter();});
function fitGraph(){const box=$('#graphViewport').getBoundingClientRect();if(!box.width)return;fit=Math.min(box.width/graphSize.width,box.height/graphSize.height)*.96;updateTransform();}
function updateTransform(){$('#graphWorld').style.transform=`translate(calc(-50% + ${pan.x}px),calc(-50% + ${pan.y}px)) scale(${fit*scale})`;$('#zoomLabel').textContent=Math.round(scale*100)+'%';}
$('#zoomIn').onclick=()=>{scale=Math.min(3.5,scale+.25);updateTransform();};$('#zoomOut').onclick=()=>{scale=Math.max(.7,scale-.25);updateTransform();};$('#zoomReset').onclick=()=>{scale=1;pan={x:0,y:0};fitGraph();};
function setupGraphInteraction(viewport){
 const pointers=new Map();let gesture=null,suppressClick=false;
 const bounded=(value,min,max)=>Math.max(min,Math.min(max,value));
 const localCenter=(a,b)=>{const r=viewport.getBoundingClientRect();return {x:(a.x+b.x)/2-r.left-r.width/2,y:(a.y+b.y)/2-r.top-r.height/2};};
 function begin(){
  const points=[...pointers.values()],a=points[0],b=points[1];
  gesture=b?{kind:'pinch',distance:Math.hypot(a.x-b.x,a.y-b.y)||1,center:localCenter(a,b),scale,pan:{...pan}}:{kind:'pan',point:a,pan:{...pan}};
 }
 function finish(e){if(!pointers.delete(e.pointerId))return;if(pointers.size)begin();else{gesture=null;viewport.style.cursor='grab';}}
 viewport.tabIndex=0;viewport.setAttribute('role','region');viewport.setAttribute('aria-label','연구자 지식 지도. 드래그로 이동, 두 손가락으로 확대·축소. 키보드는 방향키, 더하기·빼기, Home 키를 사용하세요.');
 viewport.addEventListener('pointerdown',e=>{
  if((e.pointerType==='mouse'&&e.button!==0)||(e.target.closest('button')&&!e.target.closest('.graph-node'))||pointers.size>=2)return;
  if(!pointers.size)suppressClick=false;
  pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});begin();
 });
 window.addEventListener('pointermove',e=>{
  if(!pointers.has(e.pointerId)||!gesture)return;
  pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(gesture.kind==='pinch'){
   const [a,b]=[...pointers.values()],center=localCenter(a,b);
   scale=bounded(gesture.scale*Math.hypot(a.x-b.x,a.y-b.y)/gesture.distance,.7,3.5);
   const ratio=scale/gesture.scale;
   pan={x:bounded(center.x+(gesture.pan.x-gesture.center.x)*ratio,-1000,1000),y:bounded(center.y+(gesture.pan.y-gesture.center.y)*ratio,-800,800)};
  }else{
   const dx=e.clientX-gesture.point.x,dy=e.clientY-gesture.point.y;
   if(!suppressClick&&Math.hypot(dx,dy)<6)return;
   pan={x:bounded(gesture.pan.x+dx,-1000,1000),y:bounded(gesture.pan.y+dy,-800,800)};
  }
  suppressClick=true;if(e.cancelable)e.preventDefault();viewport.style.cursor='grabbing';updateTransform();
 },{passive:false});
 window.addEventListener('pointerup',finish);
 window.addEventListener('pointercancel',finish);
 window.addEventListener('blur',()=>{pointers.clear();gesture=null;viewport.style.cursor='grab';});
 viewport.addEventListener('click',e=>{if(suppressClick&&e.detail!==0){suppressClick=false;e.preventDefault();e.stopImmediatePropagation();}},true);
 viewport.addEventListener('keydown',e=>{
  if(e.target!==viewport)return;
  if(e.key==='ArrowLeft')pan.x=bounded(pan.x+40,-1000,1000);
  else if(e.key==='ArrowRight')pan.x=bounded(pan.x-40,-1000,1000);
  else if(e.key==='ArrowUp')pan.y=bounded(pan.y+40,-800,800);
  else if(e.key==='ArrowDown')pan.y=bounded(pan.y-40,-800,800);
  else if(e.key==='+'||e.key==='=')scale=bounded(scale+.25,.7,3.5);
  else if(e.key==='-')scale=bounded(scale-.25,.7,3.5);
  else if(e.key==='Home'){scale=1;pan={x:0,y:0};}
  else return;
  e.preventDefault();updateTransform();
 });
}
setupGraphInteraction($('#graphViewport'));window.addEventListener('resize',fitGraph);
$('#graphInfo').onclick=()=>toast(meta.graphNote);$('#resetEmpty').onclick=clearSearch;$('#clearSearch').onclick=clearSearch;
const aliases={'단백질':['hodgkin','doudna'],'구조':['hodgkin','doudna'],'빛':['einstein','feynman','curie'],'물질':['einstein','feynman','curie'],'분자':['sharpless','doudna','hodgkin'],'설계':['sharpless','doudna'],'유전자':['doudna'],'dna':['doudna','hodgkin'],'crispr':['doudna'],'클릭':['sharpless'],'양자':['einstein','feynman'],'방사':['curie'],'배터리':[]};
function rank(query){const normalized=query.toLowerCase().trim(),exact=experts.find(e=>e.name.toLowerCase()===normalized||e.nameEn.toLowerCase()===normalized);if(exact)return [{e:exact,score:100,reason:['이름 일치']}];const terms=normalized.split(/\s+/).filter(Boolean);return experts.map(e=>{const hay=[e.name,e.nameEn,e.specialty,e.searchField,...e.tags,...(e.works||[]).map(w=>w.title),...e.papers.map(p=>p.title),...(e.patents||[]).map(p=>p.title+' '+p.number+' '+(p.titleKo||''))].join(' ').toLowerCase();let score=0,reason=[];terms.forEach(t=>{if(hay.includes(t)){score+=3;reason.push(t);}Object.entries(aliases).forEach(([k,ids])=>{if(t.includes(k)&&ids.includes(e.id)){score+=2;reason.push(k);}});});return {e,score,reason:[...new Set(reason)]};}).filter(r=>r.score>0).sort((a,b)=>b.score-a.score);}
async function search(query){const thisSearch=++searchGeneration;$('#query').value=query;filter='all';groupFilter='all';$$('[data-group]').forEach(b=>b.classList.toggle('active',b.dataset.group==='all'));scale=1;pan={x:0,y:0};$$('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));if(!query.trim())return clearSearch();changeView('explore');const steps=$$('.agent-step');for(let i=0;i<3;i++){if(thisSearch!==searchGeneration)return;steps.forEach((el,j)=>{el.classList.toggle('running',i===j);$('b',el).textContent=j<i?'✓':j===i?'⋯':'·';});await new Promise(r=>setTimeout(r,350));}if(thisSearch!==searchGeneration)return;steps.forEach(el=>{el.classList.remove('running');$('b',el).textContent='✓';});const results=rank(query);matched=results.map(r=>r.e.id);applyFilter();$('#clearSearch').hidden=false;$('#searchResults').hidden=!results.length;$('#searchResults').innerHTML=`<h3>“${esc(query)}”과 연결된 연구자 ${results.length}명 <small style="color:#839577;font-size:9px">· 키워드 기반 추천</small></h3>`+results.map(({e,reason})=>`<button class="result-row" data-expert="${e.id}"><img src="${e.thumbnail}" alt=""><div><strong>${e.name}</strong><small>${esc(reason.join(' · '))} 관련 연구 · ${e.specialty}</small></div><span>카드 보기 ↗</span></button>`).join('');$$('[data-expert]',$('#searchResults')).forEach(b=>b.onclick=()=>openExpert(b.dataset.expert));applyFilter();hydrogenAudio.play('discovery');toast(results.length?`${results.length}명의 연구자와 연결했어요.`:'이 키워드와 연결된 연구자는 아직 없어요.');}
function clearSearch(){searchGeneration++;matched=null;filter='all';groupFilter='all';$$('[data-group]').forEach(b=>b.classList.toggle('active',b.dataset.group==='all'));scale=1;pan={x:0,y:0};$('#query').value='';$('#clearSearch').hidden=true;$('#searchResults').hidden=true;$$('[data-filter]').forEach(b=>b.classList.toggle('active',b.dataset.filter==='all'));$$('.agent-step').forEach(el=>{el.classList.remove('running');$('b',el).textContent='✓';});applyFilter();}
$('#searchForm').onsubmit=e=>{e.preventDefault();search($('#query').value);};$$('[data-query]').forEach(b=>b.onclick=()=>search(b.dataset.query));
function renderCollection(){const q=$('#collectionQuery').value.trim().toLowerCase(),field=$('#collectionField').value;const visible=experts.filter(e=>(collectionGroup==='all'||e.collection===collectionGroup)&&(field==='all'||e.field===field)&&[e.name,e.nameEn,e.specialty,...e.tags].join(' ').toLowerCase().includes(q));$('#collectionCount').textContent=visible.length+'명의 연구자';$('#collectionEmpty').hidden=visible.length>0;$('#collectionGrid').innerHTML=visible.map(e=>`<button class="collection-item" data-expert="${e.id}"><img src="${e.thumbnail}" loading="lazy" alt="${e.name} 캐리커처"><span class="collect-serial">H₂ / ${serial(e)}</span><div class="collect-info"><span class="eyebrow">${esc(dateLabel(e))}</span><h2>${e.name}</h2><p>${e.specialty}</p><div><span>${e.collection==='korea'?'한국 과학자의 이야기':'연구자의 이야기'}</span><span>↗</span></div></div></button>`).join('');$$('[data-expert]',$('#collectionGrid')).forEach(b=>b.onclick=()=>openExpert(b.dataset.expert));}
$$('[data-collection]').forEach(b=>b.onclick=()=>{collectionGroup=b.dataset.collection;$$('[data-collection]').forEach(x=>x.classList.toggle('active',x===b));renderCollection();});
$('#collectionQuery').oninput=renderCollection;$('#collectionField').onchange=renderCollection;
function openExpert(id){selected=byId(id);detailTab='research';const e=selected;$('#expertName').textContent=e.name;$('#expertSubtitle').textContent=e.nameEn+' · '+e.specialty;$('#flipCard').classList.remove('flipped');$('#flipCard').setAttribute('aria-label',`${e.name} 카드 뒤집어 업적 보기`);$('#flipHint').textContent='⤾ 카드를 한 번 더 눌러 업적 보기';$('#flipCard').innerHTML=`<div class="card-face card-front"><div class="card-head"><strong>${e.name}</strong><span>H₂ ✦</span></div><img class="card-art" src="${e.cardPortrait}" alt="${e.name} 연구자 캐릭터"><div class="card-metadata"><p class="card-tagline">${e.tagline}</p><p class="card-field">${e.specialty}<br>${esc(dateLabel(e))}</p></div><div class="card-foot"><span>SUSOMOON · SCIENTIST COLLECTION</span><span>${serial(e)} / ${total}</span></div></div><div class="card-face card-back"><span class="eyebrow">A LIFETIME OF DISCOVERY</span><h3>${e.name}</h3><p class="back-nobel">${esc(e.nobel||e.recognition||e.specialty)}</p><ul>${e.achievements.map(a=>`<li>${a}</li>`).join('')}</ul><div class="patent-count">${e.patents?.length ? `특허·출원 문헌 ${e.patents.length}건 확인` : `특허 문헌 연결 현황: 확인된 목록 없음`}</div><small>공개 자료에 기반한 학습용 카드<br>인물의 서비스 참여·추천을 의미하지 않습니다.<br>H₂ · ${serial(e)} / ${total}</small></div>`;renderDetail();if(!$('#expertDialog').open){lastFocus=document.activeElement;$('#expertDialog').showModal();if(demoTimers.length){$('#demoDialogCaption').hidden=false;$('#demoDialogText').textContent=$('#demoText').textContent;}}hydrogenAudio.play('discovery');}
function flip(){const flipped=$('#flipCard').classList.toggle('flipped');$('#flipCard').setAttribute('aria-label',flipped?'카드 앞면 보기':'카드 뒤집어 업적 보기');$('#flipHint').textContent=flipped?'⤾ 다시 눌러 연구자 얼굴 보기':'⤾ 카드를 한 번 더 눌러 업적 보기';hydrogenAudio.play('card-flip');}
$('#flipCard').onclick=flip;$('#flipHint').onclick=flip;$('#closeExpert').onclick=()=>$('#expertDialog').close();$('#expertDialog').addEventListener('click',e=>{if(e.target===$('#expertDialog')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close();}});$('#expertDialog').addEventListener('close',()=>lastFocus?.focus());
$$('[data-detail]').forEach(b=>b.onclick=()=>{detailTab=b.dataset.detail;renderDetail();});
function renderDetail(){if(!selected)return;const e=selected,comments=store.getState().comments.filter(c=>c.expertId===e.id);$('#commentCount').textContent=comments.length;$$('[data-detail]').forEach(b=>{b.classList.toggle('active',b.dataset.detail===detailTab);b.setAttribute('aria-selected',b.dataset.detail===detailTab?'true':'false');});const box=$('#detailContent');if(detailTab==='research'){box.innerHTML=`<p class="research-summary">${esc(e.summary)}</p><div class="tag-list">${e.tags.map(t=>`<span>${esc(t)}</span>`).join('')}</div>${researchRecords(e)}${patentSection(e)}<a class="source-link" href="${esc(e.sourceUrl)}" target="_blank" rel="noopener noreferrer">${esc(e.sourceLabel||'노벨 재단에서 업적 확인')} ↗</a>${e.portraitNote?`<p class="portrait-note">이미지 안내 · ${esc(e.portraitNote)}</p>`:''}<p class="detail-note">출처 기반 정적 요약이며 실시간 AI 검색 결과가 아닙니다. 인물의 실제 연락 가능성을 의미하지 않습니다.</p>`;}else if(detailTab==='connections'){const related=links.filter(l=>[l.source,l.target].includes(e.id));box.innerHTML=`<p class="detail-note">${meta.graphNote}</p>`+related.map(l=>{const other=byId(l.source===e.id?l.target:l.source);return `<button class="connection-row" data-expert="${other.id}"><img src="${other.thumbnail}" alt=""><div><strong>${other.name}</strong><small>${esc(l.label)} · 개념 연결</small></div><span>↗</span></button><p class="connection-explanation">${esc(l.explanation)}</p>`}).join('');$$('[data-expert]',box).forEach(b=>b.onclick=()=>openExpert(b.dataset.expert));}else{box.innerHTML=`<div class="comment-reward">✦ 연구에서 얻은 생각을 나눠 주세요.<br>카드별 하루 첫 방명록을 남기면 +1 H₂</div><form id="commentForm"><textarea id="commentText" aria-label="연구자 카드에 방명록 남기기" minlength="5" maxlength="500" required placeholder="어떤 발견이 인상 깊었나요? (5자 이상)"></textarea><button class="primary-button" type="submit">생각 남기기 · 수소 받기</button></form><div id="commentList">${comments.length?comments.slice().reverse().map(c=>`<article class="comment"><small>${esc(store.getState().profile.name)} · ${new Date(c.createdAt).toLocaleDateString('ko-KR')}</small><p>${esc(c.text)}</p></article>`).join(''):'<p class="empty-comments"><span>✎</span>첫 번째 연구 노트를 남겨보세요.</p>'}</div><p class="detail-note">방명록과 수소는 이 브라우저에만 저장되는 데모입니다. 실제 인물에게 전달되지 않습니다.</p>`;$('#commentForm').onsubmit=ev=>{ev.preventDefault();const result=store.addComment(e.id,$('#commentText').value);toast(result.message);if(result.ok){renderDetail();updateBalance();if(result.reward)hydrogenAudio.play('hydrogen-collect');}};}}
const avatarSVG=`<svg viewBox="0 0 280 280" aria-label="얼굴 특징이 고정된 샘플 연구자 캐릭터" role="img"><g opacity=".24" stroke="#effff2" fill="none"><ellipse cx="140" cy="142" rx="116" ry="56" transform="rotate(-30 140 142)"/><ellipse cx="140" cy="142" rx="110" ry="50" transform="rotate(40 140 142)"/><circle cx="36" cy="170" r="8" fill="#d3e8b1"/><circle cx="211" cy="214" r="5" fill="#d3e8b1"/></g><path d="M58 283 Q55 201 108 185 L173 185 Q225 204 226 283" fill="#f1f5ed"/><path d="M115 176 L114 204 L141 233 L168 204 L165 176" fill="#ddaa83"/><path d="M122 208 L141 226 L162 208 L166 280 L115 280" fill="#638474"/><path d="M109 190 L141 232 L112 249 L89 206 Z M171 190 L141 232 L168 249 L191 206 Z" fill="#ffffff" stroke="#ccd9ce"/><path d="M110 104 Q116 177 142 185 Q175 177 181 103" fill="#e8b88e"/><ellipse cx="108" cy="128" rx="8" ry="13" fill="#d9a981"/><ellipse cx="179" cy="128" rx="8" ry="13" fill="#d9a981"/><path d="M107 118 Q90 65 134 57 Q183 45 184 108 L174 122 L171 89 Q140 104 118 88 L116 121 Z" fill="#292e32"/><path d="M109 92 Q104 59 147 57 Q176 57 179 83 Q153 72 130 90" fill="#3e4347"/><path d="M121 119 Q128 115 134 119 M151 119 Q158 115 165 119" fill="none" stroke="#3c3932" stroke-width="3" stroke-linecap="round"/><ellipse cx="128" cy="130" rx="3.5" ry="5" fill="#303236"/><ellipse cx="157" cy="130" rx="3.5" ry="5" fill="#303236"/><circle cx="129" cy="128" r="1.1" fill="white"/><circle cx="158" cy="128" r="1.1" fill="white"/><path d="M143 132 L140 147 L147 147" fill="none" stroke="#c58b6a" stroke-width="2" stroke-linecap="round"/><path d="M131 159 Q143 168 156 158" fill="none" stroke="#925d4f" stroke-width="2.5" stroke-linecap="round"/><path d="M185 246 L209 246 L208 267 L185 267 Z" fill="#dbe5df"/><path d="M194 239 L194 254" stroke="#6c9d79" stroke-width="3"/></svg>`;
function updateBalance(){$('#balance').textContent=store.getState().balance;}
function renderMyCard(){const s=store.getState(),p=s.profile;$('#myCard').innerHTML=`<div class="personal-card ${esc(s.equipped.finish||'')}"><div class="pc-top">${esc(p.name||'나의 연구자')}<span>H₂ ${s.balance}</span></div><div class="personal-art">${avatarSVG}${s.equipped.accessory?`<span class="accessory ${s.equipped.accessory}">${s.equipped.accessory==='glasses'?'👓':'🎩'}</span>`:''}${s.equipped.badge?'<span class="atom-badge">⚛</span>':''}</div><div class="pc-description"><strong>${esc(p.specialty||'아직 발견되지 않은 가능성')}</strong><p>${esc(p.intro||'나의 경험을 채워, 새로운 연결을 시작해 보세요.')}</p><small>${esc(p.team||'YOUR NEXT DISCOVERY STARTS HERE')} · MY RESEARCHER CARD</small></div></div>`;}
function renderShop(){const s=store.getState(),icons={holo:'◈',sparkle:'✦',glasses:'👓',hat:'🎩',atomBadge:'⚛'};$('#shop').innerHTML=Object.values(SusomoonState.ITEMS).map(item=>{const owned=s.owned.includes(item.id),equipped=s.equipped[item.slot]===item.id;return `<button class="shop-item ${equipped?'equipped':''}" data-item="${item.id}" aria-label="${item.name} ${equipped?'착용 중':owned?'무료 착용':item.cost+' 수소로 구매'}"><span>${icons[item.id]}</span><strong>${item.name}</strong><small>${equipped?'✓ 착용 중':owned?'보유 · 무료 착용':item.cost+' H₂'}</small></button>`}).join('');$$('[data-item]').forEach(b=>b.onclick=()=>{const item=SusomoonState.ITEMS[b.dataset.item],s=store.getState();const r=s.owned.includes(item.id)?store.equip(item.slot,item.id):store.purchase(item.id);toast(r.message);if(r.ok){renderMyCard();renderShop();updateBalance();hydrogenAudio.play('badge-equip');}});}
function renderProfile(){const s=store.getState();Object.entries(s.profile).forEach(([k,v])=>{const input=$(`[name="${k}"]`,$('#profileForm'));if(input)input.value=v;});$('#profileProgress').textContent=`${s.profileRewarded.length} / 4 항목 완성`;renderMyCard();renderShop();}
$('#profileForm').onsubmit=e=>{e.preventDefault();let reward=0,error='';const values=Object.fromEntries(new FormData(e.currentTarget));Object.entries(values).forEach(([field,value])=>{const before=store.getState().profile[field];if(String(value).trim()===before)return;const r=store.addProfile(field,value);if(r.ok)reward+=r.reward||0;else error=r.message;});renderProfile();updateBalance();toast(error|| (reward?`프로필 완성! 수소 +${reward} H₂를 받았어요.`:'프로필을 저장했어요. 이미 적립한 항목에는 보상이 반복되지 않아요.'));if(reward)hydrogenAudio.play('hydrogen-collect');};
$('#removeCosmetics').onclick=()=>{['finish','accessory','badge'].forEach(slot=>store.equip(slot,null));renderMyCard();renderShop();toast('기본 스타일로 돌아왔어요. 구매한 장식은 보관됩니다.');};
function stopDemo(){demoTimers.forEach(clearTimeout);demoTimers=[];$('#demoOverlay').hidden=true;$('#demoDialogCaption').hidden=true;}
function startDemo(){stopDemo();$('#expertDialog').close();changeView('explore');clearSearch();$('#demoOverlay').hidden=false;const schedule=[[0,'01 / 질문에서 시작합니다. “단백질 구조”를 수소문해 볼까요?',()=>search('단백질 구조')],[6500,'02 / 근거로 연결한 연구자의 카드를 만나보세요.',()=>openExpert('hodgkin')],[14000,'03 / 카드를 뒤집으면 업적과 발견의 맥락이 나타납니다.',()=>flip()],[21000,'04 / 관련된 분야를 따라 다음 연구자로 연결됩니다.',()=>{detailTab='connections';renderDetail();}],[28000,'05 / 프로필을 채우면 수소를 받고, 나의 카드를 꾸밀 수 있어요.',()=>{$('#expertDialog').close();changeView('mycard');}],[37000,'06 / 96초 홍보 영상과 오리지널 사운드도 준비했습니다.',()=>changeView('studio')],[45000,'',()=>{stopDemo();changeView('explore');clearSearch();toast('시연을 마쳤어요. 이제 직접 발견을 시작해 보세요.');}]];schedule.forEach(([time,text,fn])=>demoTimers.push(setTimeout(()=>{$('#demoText').textContent=text;$('#demoDialogText').textContent=text;$('#demoProgress').style.width=(time/45000*100)+'%';fn();},time)));}
$('#stopDemoInDialog').onclick=()=>{stopDemo();$('#expertDialog').close();};$('#demoButton').onclick=startDemo;$('#stopDemo').onclick=()=>{stopDemo();$('#expertDialog').close();};
$('#navExpertCount').textContent=experts.length;$('#expertTotal').textContent=experts.length;$('#linkTotal').textContent=links.length;$('#allCount').textContent=experts.length;$('#dataSummary').textContent='공개 연구자 '+experts.length+'명 · 논문 '+experts.reduce((s,e)=>s+e.papers.length,0)+'편 · 저술·발명·대표 성과와 확인된 특허 문헌. 사내 자료 연결·실시간 AI 검색 전 단계입니다.';
renderGraph();renderCollection();renderProfile();updateBalance();fitGraph();
orbitScene=installOrbitMotion({getExperts:activeExperts,links,onFit:layout=>{graphSize=layout;fitGraph();}});
window.susomoonDemo={start:startDemo,stop:stopDemo};



function patentSection(e){
 const patents=e.patents||[];
 return '<span class="detail-label">특허 · 출원 문헌</span>'+ (patents.length?patents.map(p=>`<div class="paper-block patent-block"><small>${esc(p.number)} · ${esc(p.year)}</small><h3>${esc(p.title)}</h3><p>발명자: ${esc(p.inventors)}</p><p>${esc(p.summary)}</p><a href="${esc(p.url)}" target="_blank" rel="noopener noreferrer">특허 원문 · 발명자 확인 ↗</a><p class="detail-note">${esc(p.statusNote)}</p></div>`).join(''):'') + (e.patentNote?`<p class="patent-empty">${esc(e.patentNote)}</p>`:patents.length?'':'<p class="patent-empty">이번 데모에서 발명자가 일치하는 특허를 아직 연결하지 않았습니다. 특허가 없다는 의미는 아닙니다.</p>');
}


function researchRecords(e){return [...e.papers.map(p=>({...p,kind:'대표 논문'})),...(e.works||[])].map(p=>`<span class="detail-label">${esc(p.kind||'대표 성과')} · ${esc(p.year||'')}</span><div class="paper-block"><small>${esc(p.journal||p.sourceLabel||'공개 기록 기반')}</small><h3>${esc(p.title)}</h3><p>${esc(p.summary)}</p><a href="${esc(p.url)}" target="_blank" rel="noopener noreferrer">원문 및 근거 자료 ↗</a></div>`).join('')||'<p class="detail-note">대표 문헌의 서지 정보를 확인 중입니다.</p>';}
