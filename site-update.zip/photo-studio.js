const MAX_FILE_BYTES=10*1024*1024;
export function cropRect(width,height,zoom=1,vertical=50){
  const side=Math.min(width,height)/Math.max(1,Math.min(2.5,Number(zoom)||1));
  return {x:(width-side)/2,y:(height-side)*Math.max(0,Math.min(100,Number(vertical)||0))/100,size:side};
}
export function checkPhoto(file){
  if(!file||!['image/jpeg','image/png','image/webp'].includes(file.type))return 'JPG·PNG·WebP 사진을 선택해 주세요. HEIC는 JPG로 내보낸 뒤 사용할 수 있어요.';
  if(!file.size||file.size>MAX_FILE_BYTES)return '사진 크기는 10MB 이하로 선택해 주세요.';
  return '';
}
export function installPhotoStudio({portraitStore,onApply,getProfile,toast}){
  const $=s=>document.querySelector(s),panel=$('#photoStudio'),input=$('#portraitPhoto');
  const canvas=$('#portraitCrop'),ctx=canvas.getContext('2d'),generate=$('#generatePortrait'),apply=$('#applyPortrait');
  const config=window.SUSOMOON_PORTRAIT_CONFIG||{},apiBase=String(config.apiBase||'').replace(/\/$/,'');
  let original=null,previewUrl='',result=null,resultStyle='classic',ready=false,busy=false,controller=null,selection=0;
  function status(text){$('#portraitStatus').textContent=text;}
  function refresh(){generate.disabled=!original||!ready||busy||!$('#portraitConsent').checked||$('#portraitAccess').value.trim().length<20;apply.disabled=!result||busy;$('#cancelPortrait').hidden=!busy;panel.setAttribute('aria-busy',String(busy));}
  function draw(){if(!original)return;const r=cropRect(original.naturalWidth,original.naturalHeight,$('#portraitZoom').value,$('#portraitPosition').value);ctx.fillStyle='#dce8de';ctx.fillRect(0,0,768,768);ctx.drawImage(original,r.x,r.y,r.size,r.size,0,0,768,768);}
  function load(src){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('사진을 읽을 수 없어요. 다른 JPG·PNG 사진을 선택해 주세요.'));img.src=src;});}
  async function select(file){
    if(busy)return;const serial=++selection,error=checkPhoto(file);if(error){status(error);input.value='';return;}
    const url=URL.createObjectURL(file);
    try{const img=await load(url);if(serial!==selection)return;if(img.naturalWidth<200||img.naturalHeight<200)throw new Error('얼굴이 선명한 200×200픽셀 이상의 사진을 선택해 주세요.');if(img.naturalWidth*img.naturalHeight>50000000)throw new Error('사진 해상도가 너무 커요. 5천만 화소 이하로 줄여 주세요.');
      if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=url;original=img;result=null;$('#portraitResult').hidden=true;$('#portraitEditor').hidden=false;$('#portraitZoom').value='1';$('#portraitPosition').value='50';draw();status(ready?'구도를 확인하고 AI 캐리커처를 생성해 주세요.':'사진 미리보기가 준비됐어요. AI 생성 서버 연결 후 변환할 수 있어요.');
    }catch(error){status(error.message);}finally{if(previewUrl!==url)URL.revokeObjectURL(url);input.value='';refresh();}
  }
  async function connect(){
    if(!apiBase){$('#portraitConnection').textContent='AI 생성 서버 연결 대기 · 사진 미리보기 가능';refresh();return;}
    try{const url=new URL(apiBase);if(url.protocol!=='https:'&&!['127.0.0.1','localhost'].includes(url.hostname))throw new Error('Insecure endpoint');
      const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),8000);let response;
      try{response=await fetch(apiBase+'/api/caricature/status',{signal:abort.signal,credentials:'omit',cache:'no-store'});}finally{clearTimeout(timer);}
      const data=await response.json();ready=response.ok&&data.ready===true;$('#portraitConnection').textContent=ready?'AI 생성 연결됨 · 연구자 카드 스튜디오':'AI 생성 서버 준비 중 · 사진 미리보기 가능';
    }catch(_){$('#portraitConnection').textContent='AI 생성 서버에 연결하지 못했어요. 잠시 후 다시 확인해 주세요.';}
    refresh();
  }
  input.addEventListener('change',()=>select(input.files?.[0]));
  $('#choosePortrait').onclick=()=>input.click();
  const drop=$('#portraitDrop');drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('drag-over');});drop.addEventListener('dragleave',()=>drop.classList.remove('drag-over'));drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('drag-over');if(e.dataTransfer.files.length!==1){status('한 명의 얼굴이 나온 사진 한 장을 선택해 주세요.');return;}select(e.dataTransfer.files[0]);});
  ['#portraitZoom','#portraitPosition'].forEach(s=>$(s).addEventListener('input',draw));
  ['#portraitConsent','#portraitAccess'].forEach(s=>$(s).addEventListener('input',refresh));
  $('#checkPortraitConnection').onclick=connect;
  $('#cancelPortrait').onclick=()=>controller?.abort();
  generate.onclick=async()=>{
    if(generate.disabled)return;busy=true;result=null;$('#portraitResult').hidden=true;refresh();status('AI가 얼굴 특징을 참고해 그림을 그리고 있어요. 잠시 기다려 주세요.');
    controller=new AbortController();const timer=setTimeout(()=>controller.abort(),170000);
    panel.querySelectorAll('[data-photo-lock]').forEach(e=>e.disabled=true);
    try{
      const chosenStyle=$('#portraitStyle').value;
      const response=await fetch(apiBase+'/api/caricature',{method:'POST',credentials:'omit',signal:controller.signal,headers:{'Content-Type':'application/json','Authorization':'Bearer '+$('#portraitAccess').value.trim()},body:JSON.stringify({image:canvas.toDataURL('image/jpeg',.88),style:chosenStyle,specialty:String(getProfile().specialty||'과학 연구').slice(0,120),consent:true})});
      const data=await response.json();if(!response.ok)throw new Error(data.message||'생성을 완료하지 못했어요. 잠시 후 다시 시도해 주세요.');
      if(typeof data.image!=='string'||data.image.length>9000000||!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(data.image))throw new Error('생성된 이미지 형식을 확인하지 못했어요.');
      const img=await load(data.image),output=document.createElement('canvas');output.width=output.height=640;const r=cropRect(img.naturalWidth,img.naturalHeight);output.getContext('2d').drawImage(img,r.x,r.y,r.size,r.size,0,0,640,640);result=output.toDataURL('image/jpeg',.86);resultStyle=chosenStyle;
      if(!window.SusomoonPortrait.validImage(result))throw new Error('생성된 이미지가 너무 커서 저장할 수 없어요.');
      $('#portraitGenerated').src=result;$('#portraitDownload').href=result;$('#portraitResult').hidden=false;status('캐리커처가 완성됐어요. 얼굴이 잘 표현됐는지 확인하고 카드에 적용해 주세요.');
    }catch(error){result=null;status(error.name==='AbortError'?'생성 대기를 중단했어요. 기존 카드는 그대로 유지됩니다. 이미 시작된 AI 요청에는 비용이 발생할 수 있어요.':error.message||'네트워크 연결을 확인해 주세요.');}
    finally{clearTimeout(timer);controller=null;busy=false;panel.querySelectorAll('[data-photo-lock]').forEach(e=>e.disabled=false);refresh();}
  };
  apply.onclick=()=>{if(!result)return;const saved=portraitStore.save({version:1,image:result,style:resultStyle});if(!saved.ok){status(saved.message);return;}onApply();status(saved.persistent?'내 카드에 적용하고 이 브라우저에 저장했어요.':'내 카드에 적용했어요. 현재 임시 모드이므로 새로고침하면 사라져요.');toast('나만의 연구자 카드가 완성됐어요.');};
  connect();
  window.addEventListener('pagehide',()=>{controller?.abort();if(previewUrl)URL.revokeObjectURL(previewUrl);});
}
