/* Small DOM-based 3D projection: original buttons remain focusable and clickable. */
export function installOrbitMotion({getExperts,links,onFit}) {
  const viewport=document.querySelector('#graphViewport');
  const world=document.querySelector('#graphWorld');
  const center=world.querySelector('.graph-center');
  center.style.zIndex=String(window.SusomoonOrbit.layerForDepth(0));
  const nodes=document.querySelector('#nodes');
  const edges=document.querySelector('#edges');
  const toggle=document.querySelector('#motionToggle');
  const status=document.querySelector('#motionStatus');
  const explore=document.querySelector('#exploreView');
  const dialog=document.querySelector('#expertDialog');
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
  let enabled=!reduced.matches,clock=0,last=0,raf=0,inView=true;
  let hovering=false,focusing=false,dragging=false,visible=[],cards=[],connections=[];
  let rotation=[0,0,0,1];

  function canRun() {
    return enabled&&visible.length>1&&!document.hidden&&inView&&
      explore.classList.contains('active')&&!dialog.open&&!hovering&&!focusing&&!dragging;
  }
  function draw() {
    const layout=window.SusomoonOrbit.sample(visible,clock,{rotation});
    for(const {id,button} of cards) {
      const [x,y,angle]=layout.positions[id],depth=layout.depths[id];
      button.style.transform=`translate3d(${x.toFixed(2)}px,${y.toFixed(2)}px,0) translate(-50%,-50%) scale(${depth.scale.toFixed(4)}) rotate(${angle.toFixed(2)}deg)`;
      // Opaque cards actually occlude the origin; dim distant cards without
      // making H2 show through foreground portraits. Hover never changes depth.
      button.style.opacity='1';
      button.style.setProperty('--orbit-brightness',depth.opacity.toFixed(3));
      button.style.zIndex=String(window.SusomoonOrbit.layerForDepth(depth.z));
      button.style.setProperty('--orbit-y',depth.rotateY.toFixed(2)+'deg');
    }
    for(const {link,group,line,text} of connections) {
      const a=layout.positions[link.source],b=layout.positions[link.target];
      if(!a||!b)continue;
      line.setAttribute('x1',a[0]);line.setAttribute('y1',a[1]);
      line.setAttribute('x2',b[0]);line.setAttribute('y2',b[1]);
      text.setAttribute('x',(a[0]+b[0])/2);text.setAttribute('y',(a[1]+b[1])/2-6);
      group.style.opacity=((layout.depths[link.source].opacity+layout.depths[link.target].opacity)/2).toFixed(3);
    }
  }
  function tick(now) {
    raf=0;
    if(!canRun()){sync();return;}
    const elapsed=now-last;
    // 30 fps is sufficient for this slow motion and avoids unnecessary mobile work.
    if(elapsed>=32){
      clock+=Math.min(elapsed,80)/1000;last=now;
      draw();
    }
    raf=requestAnimationFrame(tick);
  }
  function sync() {
    const running=canRun();
    viewport.dataset.motion=running?'running':'paused';
    viewport.dataset.dragging=String(dragging);
    toggle.setAttribute('aria-pressed',String(enabled));
    toggle.setAttribute('aria-label',enabled?'자동 회전 끄기':'자동 회전 켜기');
    toggle.innerHTML=enabled?'<span aria-hidden="true">Ⅱ</span> 회전 멈춤':'<span aria-hidden="true">▷</span> 회전 시작';
    status.textContent=visible.length===0?'새로운 연결을 찾아보세요':visible.length===1?'한 사람의 발견을 더 가까이':
      dragging?'중앙 H₂를 중심으로 자유 회전 중':
      !enabled?'멈춘 궤도 · 상하좌우로 돌려보세요':
      hovering||focusing||dialog.open||dragging?'잠시 멈춤 · 당신의 발견을 기다리는 중':'서로의 지식이 만나는 궤도';
    if(running&&!raf){last=performance.now();raf=requestAnimationFrame(tick);}
    if(!running&&raf){cancelAnimationFrame(raf);raf=0;}
  }
  function refresh() {
    visible=getExperts();
    viewport.dataset.orbitCount=String(visible.length);
    const layout=window.SusomoonOrbit.sample(visible,clock,{rotation});
    world.classList.remove('overview');world.classList.add('orbital');
    world.style.width=layout.width+'px';world.style.height=layout.height+'px';
    edges.setAttribute('viewBox',`0 0 ${layout.width} ${layout.height}`);
    cards=[...nodes.querySelectorAll('.graph-node')].map(button=>{
      button.style.left='0';button.style.top='0';
      return {id:button.dataset.expert,button};
    });
    connections=[...edges.querySelectorAll('[data-link]')].map(group=>({
      group,link:links[Number(group.dataset.link)],line:group.querySelector('line'),text:group.querySelector('text')
    }));
    hovering=false;focusing=false;
    draw();onFit(layout);sync();
  }
  toggle.addEventListener('click',()=>{enabled=!enabled;sync();});
  nodes.addEventListener('pointerover',event=>{
    if(event.pointerType==='mouse'&&event.target.closest('.graph-node')){hovering=true;sync();}
  });
  nodes.addEventListener('pointerout',event=>{
    if(event.pointerType==='mouse'&&!event.relatedTarget?.closest?.('.graph-node')){hovering=false;sync();}
  });
  nodes.addEventListener('focusin',()=>{focusing=true;sync();});
  nodes.addEventListener('focusout',event=>{
    focusing=!!event.relatedTarget&&nodes.contains(event.relatedTarget);sync();
  });
  viewport.addEventListener('pointerleave',()=>{hovering=false;sync();});
  // Pointer ownership lives in setupGraphInteraction, shared with pinch zoom.
  // Pointer paths rotate around the fixed H2 origin, never pan the camera/world.
  function rotateFrom(from,to) {
    const box=world.getBoundingClientRect();
    rotation=window.SusomoonOrbit.drag(rotation,from,to,{
      centerX:box.left+box.width/2,centerY:box.top+box.height/2,
      radiusX:Math.max(1,box.width*.355),radiusY:Math.max(1,box.height*248/760)
    });
    draw();
  }
  function rotateBy(dx,dy=0) {
    const box=viewport.getBoundingClientRect();
    const sensitivity=Math.PI/Math.max(320,Math.min(box.width,box.height));
    rotation=window.SusomoonOrbit.turn(rotation,dx,dy,sensitivity);
    draw();
  }
  function setDragging(value) {dragging=!!value;sync();}
  function reset() {rotation=[0,0,0,1];clock=0;draw();}
  window.addEventListener('blur',()=>{dragging=false;hovering=false;sync();});
  document.addEventListener('visibilitychange',sync);
  new MutationObserver(sync).observe(explore,{attributes:true,attributeFilter:['class']});
  new MutationObserver(sync).observe(dialog,{attributes:true,attributeFilter:['open']});
  if('IntersectionObserver' in window)new IntersectionObserver(entries=>{
    inView=entries[0].isIntersecting;sync();
  },{threshold:0}).observe(viewport);
  const preference=()=>{enabled=!reduced.matches;sync();};
  if(reduced.addEventListener)reduced.addEventListener('change',preference);else reduced.addListener(preference);
  refresh();
  return {refresh,rotateBy,rotateFrom,setDragging,reset};
}
