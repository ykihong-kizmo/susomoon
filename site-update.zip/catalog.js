/* Combine curated collections without changing existing profile or wallet data. */
(function () {
  const data = window.SUSOMOON_DATA;
  data.experts.forEach(e => { e.collection = e.collection || 'nobel'; });
  const korean = window.SUSOMOON_KOREAN;
  if (korean) {
    const ids = new Set(data.experts.map(e => e.id));
    korean.experts.forEach(e => { if (!ids.has(e.id)) { data.experts.push(e); ids.add(e.id); } });
    data.links.push(...korean.links);
    data.meta.factsCheckedAt=korean.meta.factsCheckedAt;
  }
  const researchers = window.SUSOMOON_RESEARCHERS;
  if (researchers) {
    const ids = new Set(data.experts.map(e=>e.id));
    researchers.experts.forEach(e=>{if(!ids.has(e.id)){data.experts.push(e);ids.add(e.id);}});
    data.links.push(...researchers.links);
  }
  const fields={chemistry:'화학',physics:'물리학',life:'생명과학 의학 생물학',engineering:'공학 발명',mathematics:'수학',earth:'지구과학 지리 천문학'};
  data.experts.forEach(e=>{e.searchField=fields[e.field]||e.field;e.thumbnail='assets/thumbs/'+e.id+'.webp';e.cardPortrait='assets/cards/'+e.id+'.webp';});
  data.meta.patentNote='특허 문헌 '+data.experts.reduce((count,e)=>count+(e.patents||[]).length,0)+'건의 출처를 연결했습니다. 전체 특허 목록이나 현재 권리 상태를 뜻하지 않습니다.';
  data.meta.summaryNote = '검토한 공개 자료의 정적 요약입니다. 시대에 따라 논문·저술·발명·대표 연구를 구분합니다.';
})();
