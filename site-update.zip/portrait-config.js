// Public address only. API keys and team access codes must never be added here.
window.SUSOMOON_PORTRAIT_CONFIG=Object.freeze({apiBase:''});
