/* Curated, deterministic discovery. Scores are ordering signals, not confidence. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.SusomoonResearch=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const concepts=[
  ['클릭 화학',['클릭','click','아지드','azide','알카인','alkyne','acetylene']],
  ['촉매',['촉매','cataly','copper']],['합성',['합성','synthesis','synthetic','ligation']],
  ['구조',['구조','structure','결정학','crystallograph','x선','x-ray']],
  ['단백질',['단백질','protein']],['RNA',['rna','리보핵산']],['DNA',['dna','디옥시리보핵산']],
  ['유전자',['유전자','유전체','genome','genetic']],['CRISPR',['crispr','cas9']],
  ['반도체',['반도체','semiconductor','mosfet']],['양자',['양자','quantum','qed']],
  ['빛',['빛','light','photoelectric']],['방사',['방사','radioactiv']],
  ['분자',['분자','molecul']],['설계',['설계','design']],['물질',['물질','matter']],
  ['배터리',['배터리','battery','리튬']],['고분자',['고분자','polymer','copolymer']],
  ['바이오매스',['바이오매스','biomass','리그닌','lignin']],['수첨탈산소',['수첨탈산소','hydrodeoxygenation','hdo']],
  ['올레핀',['올레핀','olefin']],['윤활기유',['윤활','기유','lubricant','lubrication','base oil']],['폴리올에스테르',['폴리올에스테르','polyol ester']],
  ['스케일업',['스케일업','scale-up','양산']],['안전성',['안전성','독성','toxicity']]
 ];
 const expansions={'단백질':['hodgkin','doudna'],'구조':['hodgkin','doudna'],'빛':['einstein','feynman','curie'],'물질':['einstein','feynman','curie'],'분자':['sharpless','doudna','hodgkin'],'설계':['sharpless','doudna'],'유전자':['doudna'],'양자':['einstein','feynman']};
 const norm=value=>String(value||'').normalize('NFKC').toLowerCase();
 function contains(text,term){
  const t=norm(term),h=norm(text);if(!t)return false;
  if(/^[a-z0-9]+$/.test(t))return new RegExp('(^|[^a-z0-9])'+t+'(?:[^a-z0-9]|$)','i').test(h)||(['cataly','molecul','crystallograph','radioactiv'].includes(t)&&h.includes(t));
  return h.includes(t);
 }
 const safeUrl=value=>{try{const u=new URL(value);return u.protocol==='https:'?u.href:'';}catch{return '';}};
 function evidence(e){return [['paper','논문',e.papers],['patent','특허 문헌',e.patents],['work','저술·대표 업적',e.works]].flatMap(([kind,label,items])=>(items||[]).filter(x=>safeUrl(x.url)).map(x=>({...x,kind,label,url:safeUrl(x.url)})));}
 function termsFor(query){
  const q=norm(query).trim().slice(0,500),terms=concepts.filter(([,words])=>words.some(w=>contains(q,w))).map(([label,words])=>({label,words}));
  const ignored=new Set(['연구','관련','전문가','찾아줘','알려줘','찾기','알고','싶어','대한','새로운','누구','어떻게','하고','싶어요','추천','논문','특허','업적','좀','및','그리고']);
  for(const raw of q.split(/[\s,?!.;:]+/).filter(x=>x.length>1)){
   const broadField=terms.length&&['화학','물리학','생명과학','공학','연구자'].includes(raw);
   if(!broadField&&!ignored.has(raw)&&!terms.some(t=>t.words.some(w=>contains(raw,w))))terms.push({label:raw,words:[raw]});
  }
  return terms.slice(0,20);
 }
 const hits=(text,terms)=>terms.filter(t=>t.words.some(w=>contains(text,w))).map(t=>t.label);
 function rank(experts,query,kind='all',options={}){
  const q=norm(query).trim().slice(0,500);if(!q)return [];
  const exact=experts.find(e=>norm(e.name)===q||norm(e.nameEn)===q),terms=termsFor(q);
  return experts.filter(e=>!exact||e.id===exact.id).map(e=>{
   const profile=[e.name,e.nameEn,e.specialty,e.searchField,...(e.tags||[])].join(' ');
   const profileHits=hits(profile,terms),expanded=terms.filter(t=>(expansions[t.label]||[]).includes(e.id)).map(t=>t.label);
   const records=evidence(e).filter(r=>!options.acceptEvidence||options.acceptEvidence(r)).map(r=>({...r,hits:hits([r.title,r.titleKo,r.number,r.summary].join(' '),terms)}));
   const matchedRecords=records.filter(r=>r.hits.length>0);
   const relevant=kind==='all'?matchedRecords:matchedRecords.filter(r=>r.kind===kind);
   const exactRecords=exact?(kind==='all'?records:records.filter(r=>r.kind===kind)):[];
   const reasons=[...new Set([...profileHits,...expanded,...matchedRecords.flatMap(r=>r.hits)])];
   const score=exact?100:reasons.length*20+Math.min(relevant.length,4)*2;
   const eligible=kind==='all'?(!!exact||reasons.length>0):(!!exact?exactRecords.length>0:relevant.length>0);
   return {e,score,reason:exact?['이름 일치']:reasons,profileHits,expanded,records,matchedRecords:relevant,evidence:exact?exactRecords:relevant,eligible,exact:!!exact};
  }).filter(r=>r.eligible).sort((a,b)=>b.score-a.score||a.e.id.localeCompare(b.e.id));
 }
 function analyze(experts,query,kind='all',options={}){
  const results=rank(experts,query,kind,options),terms=termsFor(query),supported=new Set(results.flatMap(r=>r.matchedRecords.flatMap(x=>x.hits)));
  const recognized=terms.filter(t=>concepts.some(c=>c[0]===t.label)).map(t=>t.label);
  return {results,recognized,gaps:recognized.filter(t=>!supported.has(t))};
 }
 function complements(experts,links,selectedIds){
  const selected=new Set(selectedIds),found=new Map();
  for(const link of links){
   if(link.kind!=='concept')continue;
   const id=selected.has(link.source)?link.target:selected.has(link.target)?link.source:null;
   if(!id||selected.has(id)||found.has(id))continue;
   const e=experts.find(x=>x.id===id),from=experts.find(x=>x.id===(link.source===id?link.target:link.source));
   if(e&&from)found.set(id,{e,from,link});
  }
  return [...found.values()].slice(0,3);
 }
 function briefing(results,limit=3){
  const seen=new Set(),items=[];
  for(const r of results)for(const record of r.matchedRecords){
   if(seen.has(record.url)||!record.summary)continue;seen.add(record.url);
   items.push({expertId:r.e.id,expertName:r.e.name,record,summary:record.summary});
  }
  return items.slice(0,Math.max(0,Math.min(6,limit)));
 }
 function brief({experts,links,query,selectedIds,objective='',context='',kind='all',checkedAt='',options={}}){
  const selected=[...new Set(selectedIds)].map(id=>experts.find(e=>e.id===id)).filter(Boolean).slice(0,3);
  const analysis=analyze(experts,query,kind,options),ranked=new Map(rank(experts,query,kind,options).map(r=>[r.e.id,r]));
  const lines=['수소문 · 연구 상담 질문서','공개 연구자 학습용 초안 · 자동 전송되지 않습니다.','',`질문: ${String(query).slice(0,500)}`,`목표: ${String(objective).slice(0,600)||'미작성'}`,`실험 맥락·제약: ${String(context).slice(0,1200)||'미작성'}`,'','비교한 연구 관점'];
  for(const e of selected){
   const r=ranked.get(e.id),connection=links.find(l=>l.kind==='concept'&&((l.source===e.id&&selectedIds.includes(l.target))||(l.target===e.id&&selectedIds.includes(l.source))));
   lines.push(`\n• ${e.name} | ${e.specialty}`,r?`추천 단서: ${r.reason.join(' · ')}`:`보완 관점: ${connection?.label||'직접 관련 근거 미확인'}`);
   const records=r?.evidence.length?r.evidence:evidence(e).filter(p=>(kind==='all'||p.kind===kind)&&(!options.acceptEvidence||options.acceptEvidence(p)));
   lines.push(r?.evidence.length?'질문 키워드와 연결된 자료:':'대표 자료 (질문과 직접 일치 미확인):');
   for(const record of records.slice(0,2))lines.push(`  ${record.label} | ${record.title} (${record.year||'연도 미상'})\n  ${record.url}`);
   if(!records.length)lines.push('  연결된 자료 없음');
  }
  lines.push('','함께 확인할 질문','1. 위 자료의 접근법이 내 대상 물질·공정에도 적용되는가?','2. 기존 실험 조건과 다른 점, 필요한 대조군·검증 자료는 무엇인가?','3. 다음 검증의 성공 기준과 추가로 필요한 전문 분야는 무엇인가?','',`추가 자료 확인이 필요한 인식 주제: ${analysis.gaps.join(' · ')||'인식 주제 내 미일치 없음 (질문 전체의 검증을 의미하지 않음)'}`,'특허는 서지·발명자 확인 수준이며 현재 권리 상태나 실시 가능성 판단이 아닙니다.',`카탈로그 자료 검토일: ${checkedAt||'미기록'}`,'인물의 서비스 참여·연락 가능성을 뜻하지 않으며 연결선은 개념적 연관입니다.','추천은 자료·주제 일치 기준입니다. 수소·결제·카드 장식은 추천 순위에 영향을 주지 않습니다.');
  return lines.join('\n');
 }
 return {rank,analyze,evidence,complements,briefing,brief,safeUrl,termsFor};
});
