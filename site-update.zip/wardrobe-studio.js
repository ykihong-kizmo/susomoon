// Original vector accessories, drawn over the portrait without editing its face.
const atom='<g fill="none" stroke="currentColor" stroke-width="1.7"><ellipse rx="11" ry="4"/><ellipse rx="11" ry="4" transform="rotate(60)"/><ellipse rx="11" ry="4" transform="rotate(120)"/></g><circle r="2.3" fill="currentColor"/>';
const coat='M58 283 Q55 201 108 185 L114 202 L141 226 L168 202 L173 185 Q225 204 226 283Z';
const lapels='<path d="M109 190 L141 232 L112 249 L89 206Z M171 190 L141 232 L168 249 L191 206Z" fill="#dbf2e7" stroke="#55988a"/>';
const pearl=(x,y)=>`<circle cx="${x}" cy="${y}" r="4" fill="#fff3d9" stroke="#c4ac83"/><circle cx="${x-1}" cy="${y-1}" r="1.2" fill="#fff"/>`;
const ART=Object.freeze({
  mintCoat:`<path d="${coat}" fill="#78bcaa" stroke="#427d71" stroke-width="2"/><path d="M115 211 L141 229 L167 211 L163 280 H116Z" fill="#eaf3e8"/>${lapels}<path d="M184 240 H209 V263 H184Z" fill="#5d9d8c"/><path d="M195 233 V247" stroke="#ddf4eb" stroke-width="3"/><g transform="translate(197 256) scale(.45)" color="#defbd2">${atom}</g>`,
  navyBlazer:`<path d="${coat}" fill="#283c5a" stroke="#162944" stroke-width="2"/><path d="M115 205 L141 226 L167 205 L158 280 H122Z" fill="#faf0dc"/><path d="M107 187 L138 229 L110 248 L97 216 L101 202Z M175 187 L143 229 L171 248 L186 214 L181 200Z" fill="#3c5272"/><circle cx="145" cy="260" r="3" fill="#e2c88d"/><path d="M185 238 H209" stroke="#e2c88d" stroke-width="3"/>`,
  lavenderHoodie:'<path d="M58 283 Q53 218 101 197 Q100 181 117 179 Q139 215 167 180 Q185 183 183 199 Q227 211 226 283Z" fill="#a39ac8" stroke="#74688f" stroke-width="2"/><path d="M108 192 Q140 232 176 193 Q169 219 141 230 Q115 217 108 192" fill="#d4cbe8"/><path d="M117 225 V252 M165 225 V252" stroke="#f0e9fa" stroke-width="2.5"/><path d="M112 255 Q142 245 173 255 L181 278 H102Z" fill="#9287b8" stroke="#74688f"/>',
  hat:'<ellipse cx="141" cy="74" rx="56" ry="12" fill="#1c2430" stroke="#687b7c"/><path d="M108 68 L105 18 Q142 7 179 18 L173 68 Q142 81 108 68Z" fill="#2e3a4c" stroke="#758a96"/><path d="M109 51 Q142 63 176 51 L174 65 Q142 78 108 65Z" fill="#92bc81"/>',
  beret:'<path d="M93 73 Q70 36 130 35 Q181 19 195 58 Q204 81 157 86 L104 85Z" fill="#e9d7b2" stroke="#b8a681" stroke-width="2"/><path d="M103 78 Q146 91 177 76 L175 89 Q138 99 103 87Z" fill="#bb9f75"/><path d="M143 35 Q136 22 147 24" fill="none" stroke="#bb9f75" stroke-width="5"/>',
  cap:'<path d="M99 77 Q99 28 143 32 Q183 34 184 79Z" fill="#5b8179" stroke="#355951" stroke-width="2"/><path d="M106 75 Q150 66 194 78 Q217 89 195 95 Q156 80 108 86Z" fill="#99c0a4" stroke="#355951"/><path d="M139 37 V69" stroke="#a9c6ad"/><g transform="translate(144 59) scale(.65)" color="#defbd2">${atom}</g>',
  glasses:'<g fill="none" stroke="#31404a" stroke-width="3"><rect x="115" y="121" width="24" height="19" rx="5"/><rect x="147" y="121" width="24" height="19" rx="5"/><path d="M139 127 Q143 123 147 127 M109 122 L115 127 M171 127 L177 122"/></g>',
  roundGlasses:'<g fill="none" stroke="#bd914c" stroke-width="2.4"><circle cx="127" cy="130" r="13"/><circle cx="159" cy="130" r="13"/><path d="M140 127 Q143 124 146 127 M108 124 L114 128 M172 128 L179 124"/></g>',
  goggles:'<path d="M108 119 Q143 114 178 119 L175 141 Q160 149 147 138 H139 Q121 149 110 139Z" fill="#bcecf922" stroke="#93c9d4" stroke-width="3"/><path d="M102 125 H109 M177 125 H184 M117 122 L127 120" stroke="#deffff" stroke-width="3"/>',
  pearlEarrings:`<path d="M105 141 V149 M181 141 V149" stroke="#c8a66a" stroke-width="2"/>${pearl(105,152)}${pearl(181,152)}`,
  starEarrings:'<g fill="#e8c66f" stroke="#b99143"><path d="M105 140 V148 M181 140 V148"/><path d="M105 146 L107 151 L112 152 L108 156 L109 162 L105 159 L101 162 L102 156 L98 152 L103 151Z M181 146 L183 151 L188 152 L184 156 L185 162 L181 159 L177 162 L178 156 L174 152 L179 151Z"/></g>',
  atomNecklace:`<path d="M118 187 Q141 231 166 187" fill="none" stroke="#d7bc75" stroke-width="2"/><g transform="translate(142 218) scale(.7)" color="#c39d46">${atom}</g>`,
  pearlNecklace:`<path d="M116 187 Q141 224 168 187" fill="none" stroke="#c4ac83"/>${[[119,193],[125,199],[132,204],[141,206],[150,204],[158,199],[165,193]].map(([x,y])=>pearl(x,y)).join('')}`,
  atomBadge:`<circle cx="196" cy="251" r="15" fill="#254c40" stroke="#c7edaf"/><g transform="translate(196 251) scale(.9)" color="#d3f5be">${atom}</g>`,
  leafBadge:'<circle cx="196" cy="251" r="15" fill="#d4e5bd" stroke="#6b9c75"/><path d="M196 260 V246 M195 251 Q181 250 187 241 Q199 239 195 251 M197 248 Q197 235 208 241 Q211 250 197 248" fill="#659b78" stroke="#377252"/>',
  boltBadge:'<circle cx="196" cy="251" r="15" fill="#343c65" stroke="#bea5e5"/><path d="M198 239 L188 254 H196 L193 264 L205 248 H197Z" fill="#e9d797"/>'
});
const SLOT_NAMES={clothing:'옷',headwear:'모자',eyewear:'안경',earrings:'귀걸이',necklace:'목걸이',finish:'카드 효과',badge:'배지'};
const CROPS={clothing:'47 176 186 110',headwear:'77 5 140 96',eyewear:'100 107 86 46',earrings:'88 135 40 35',necklace:'110 178 66 57',badge:'175 230 42 42'};
export function outfitArtwork(equipped) {
  const art=['clothing','necklace','earrings','headwear','eyewear','badge'].map(slot=>Object.prototype.hasOwnProperty.call(ART,equipped[slot])?ART[equipped[slot]]:'').join('');
  return art?`<svg class="wardrobe-layer" viewBox="0 0 280 280" aria-hidden="true">${art}</svg>`:'';
}
function itemArtwork(item) {
  if(item.slot==='finish')return `<span class="finish-swatch ${item.id}" aria-hidden="true">${item.id==='holo'?'◈':'✦'}</span>`;
  return `<svg viewBox="${CROPS[item.slot]}" aria-hidden="true">${ART[item.id]||''}</svg>`;
}

export function installWardrobeStudio({store,onChange,onEarn,toast,play}) {
  const $=selector=>document.querySelector(selector),items=window.SusomoonState.ITEMS,packs=window.SusomoonState.PACKS;
  const dialog=$('#hydrogenDialog');let category='all',ownedOnly=false,previewId=null,wantedId=null,packId='starter',receipt=null,requestId=null,lastTrigger=null,restoreFocus=true;
  function equipment(){const equipped=store.getState().equipped;if(previewId)equipped[items[previewId].slot]=previewId;return equipped;}
  function changed(){render();onChange();}
  function preview(id){previewId=previewId===id?null:id;changed();if(window.matchMedia('(max-width:780px)').matches)$('#myCard').scrollIntoView({behavior:'smooth',block:'center'});}
  function buy(id,forceEquip=false){
    const state=store.getState(),item=items[id];if(!item)return;
    if(!state.owned.includes(id)&&state.balance<item.cost){openRecharge(id);return;}
    const result=state.owned.includes(id)?store.equip(item.slot,!forceEquip&&state.equipped[item.slot]===id?null:id):store.purchase(id);
    toast(result.message);if(result.ok){previewId=null;changed();play('badge-equip');}
  }
  function render(){
    const state=store.getState();$('#shopBalance').textContent=state.balance.toLocaleString('ko-KR');
    $('#shopCategories').innerHTML=[['all','전체'],...Object.entries(SLOT_NAMES)].map(([id,label])=>`<button type="button" data-category="${id}" aria-pressed="${category===id}">${label}</button>`).join('');
    $('#shopCategories').querySelectorAll('button').forEach(button=>button.onclick=()=>{category=button.dataset.category;render();});
    const visible=Object.values(items).filter(item=>(category==='all'||item.slot===category)&&(!ownedOnly||state.owned.includes(item.id))).sort((a,b)=>Object.keys(SLOT_NAMES).indexOf(a.slot)-Object.keys(SLOT_NAMES).indexOf(b.slot));
    $('#shop').innerHTML=visible.map(item=>{
      const owned=state.owned.includes(item.id),equipped=state.equipped[item.slot]===item.id;
      return `<article class="wardrobe-item ${equipped?'equipped':''} ${previewId===item.id?'previewed':''}"><button class="item-preview" type="button" data-preview="${item.id}" aria-label="${item.name} 미리보기"><span class="item-kind">${SLOT_NAMES[item.slot]}</span><span class="item-art">${itemArtwork(item)}</span><strong>${item.name}</strong><span class="item-preview-label">${previewId===item.id?'미리보기 중':'입어보기 ↗'}</span></button><button class="item-buy" type="button" data-buy="${item.id}" aria-label="${item.name} ${equipped?'벗기':owned?'착용':item.cost+' 수소로 구매'}">${equipped?'✓ 착용 중 · 벗기':owned?'옷장에서 착용':`${item.cost} <small>H₂</small>`}</button></article>`;
    }).join('');
    $('#shopEmpty').hidden=visible.length>0;
    $('#shop').querySelectorAll('[data-preview]').forEach(button=>button.onclick=()=>preview(button.dataset.preview));
    $('#shop').querySelectorAll('[data-buy]').forEach(button=>button.onclick=()=>buy(button.dataset.buy));
    const previewItem=items[previewId];$('#outfitPreviewTools').hidden=!previewItem;
    if(previewItem){
      $('#outfitPreviewTools').innerHTML=`<span>미리보기 · 수소가 차감되지 않아요</span><strong>${previewItem.name}</strong><div><button type="button" id="applyOutfitPreview">${state.owned.includes(previewId)?'내 카드에 착용':previewItem.cost+' H₂로 구매'}</button><button type="button" id="cancelOutfitPreview">미리보기 닫기</button></div>`;
      $('#applyOutfitPreview').onclick=()=>buy(previewId,true);$('#cancelOutfitPreview').onclick=()=>{previewId=null;changed();};
    }
    $('#equippedSummary').textContent=Object.values(state.equipped).filter(Boolean).map(id=>items[id].name).join(' · ')||'기본 스타일 · 아이템을 골라 나만의 조합을 만들어보세요.';
  }
  function renderRecharge(){
    const state=store.getState();$('#rechargeBalance').textContent=state.balance.toLocaleString('ko-KR')+' H₂';
    const item=items[wantedId],shortage=item?Math.max(0,item.cost-state.balance):0;
    $('#rechargeReason').textContent=item?`${item.name}에 ${item.cost} H₂가 필요해요. ${shortage?shortage+' H₂가 부족해요.':'충전 후 구매를 계속할 수 있어요.'}`:'수소를 충전하고, 더 다양한 나를 꾸며보세요.';
    $('#rechargeChoose').hidden=!!receipt;$('#rechargeDone').hidden=!receipt;
    if(receipt){
      $('#rechargeReceipt').textContent=`체험용 수소 ${receipt.amount.toLocaleString('ko-KR')} H₂를 받았어요.`;
      $('#rechargeContinue').textContent=item?`${item.name} 구매하기 · ${item.cost} H₂`:'상점으로 돌아가기';
      return;
    }
    $('#hydrogenPacks').innerHTML=Object.values(packs).map(pack=>`<label class="hydrogen-pack ${packId===pack.id?'selected':''}"><input type="radio" name="hydrogenPack" value="${pack.id}" ${packId===pack.id?'checked':''}><span><small>${pack.name}</small><strong>${pack.hydrogen.toLocaleString('ko-KR')} <b>H₂</b></strong></span><span class="pack-price">${pack.price.toLocaleString('ko-KR')}원<small>예시 가격</small></span></label>`).join('');
    $('#hydrogenPacks').querySelectorAll('input').forEach(input=>input.onchange=()=>{packId=input.value;renderRecharge();});
    $('#demoTopupButton').textContent=`무료로 ${packs[packId].hydrogen.toLocaleString('ko-KR')} H₂ 충전 체험`;
    $('#rechargeError').textContent='';
  }
  function openRecharge(id=null){
    wantedId=id;receipt=null;lastTrigger=document.activeElement;restoreFocus=true;
    const shortage=id?Math.max(0,items[id].cost-store.getState().balance):0;
    packId=(Object.values(packs).find(pack=>pack.hydrogen>=shortage)||packs.universe).id;
    requestId=globalThis.crypto?.randomUUID?.()||'demo-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);
    renderRecharge();if(!dialog.open)dialog.showModal();
  }
  $('#openHydrogenShop').onclick=()=>openRecharge();
  $('#ownedItemsOnly').onchange=event=>{ownedOnly=event.target.checked;render();};
  $('#closeHydrogenDialog').onclick=()=>dialog.close();
  $('#earnHydrogenInstead').onclick=()=>{restoreFocus=false;dialog.close();onEarn();};
  $('#demoTopupButton').onclick=()=>{
    const button=$('#demoTopupButton');button.disabled=true;
    const result=store.demoTopup(packId,requestId);
    button.disabled=false;
    if(!result.ok){$('#rechargeError').textContent=result.message;return;}
    receipt={amount:packs[packId].hydrogen};changed();renderRecharge();play('hydrogen-collect');
  };
  $('#rechargeContinue').onclick=()=>{const id=wantedId;dialog.close();if(id)buy(id);};
  dialog.addEventListener('close',()=>{if(!restoreFocus)return;if(lastTrigger?.isConnected)lastTrigger.focus();else $('#openHydrogenShop').focus();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const box=dialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)dialog.close();}});
  return {render,equipment,isPreviewing:()=>!!previewId,openRecharge,clearPreview:()=>{previewId=null;render();},artwork:outfitArtwork};
}
